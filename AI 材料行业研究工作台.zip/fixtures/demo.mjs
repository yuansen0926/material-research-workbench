import { createProject, saveDraft, snapshot } from "../server/projects.mjs";
import { addTextSource } from "../server/sources.mjs";
import { id } from "../server/db.mjs";
export function seedDemo(store, config) {
  const existing = store.list("projects").find(p => p.mode === "demo");
  if (existing) return existing;
  const project = createProject(store, {
    title: "磷酸锰铁锂 · 产业化验证路径",
    material: "磷酸锰铁锂", question: "在现有材料合成能力基础上，如何设计从样品到客户验证的进入路径？",
    scope: "中国市场 · 中期进入策略", profile: "自编企业案例：具备湿法合成和客户联合验证能力。", mode: "demo"
  });
  const bodies = [
    ["样例资料 A · 项目验证备忘录", "本文件为自编演示资料，不代表真实企业或行业数据。\n样品验证仍需完成长循环测试。当前仅有实验室样品记录，尚未取得客户量产定点。\n项目团队拟优先核对批次一致性、良率和与现有工艺的适配情况。客户的验证口径尚待确认。"],
    ["样例资料 B · 企业能力清单", "本文件为自编演示资料，不代表真实企业或行业数据。\n案例企业具备湿法合成和小试配方开发经验，但缺少连续量产验证记录。\n现有客户愿意开展样品评价，尚未签订采购承诺。团队建议按样品评价、小试复现、中试验证分阶段推进。"],
    ["样例资料 C · 研究缺口清单", "本文件为自编演示资料，不代表真实企业或行业数据。\n现有资料未提供可核验的市场规模、单位成本、同年度有效产能或销售价格。\n财务测算需要补充设备报价、能耗记录、材料消耗和客户认证周期，不能用名义产能直接估算盈利。"]
  ];
  bodies.forEach(([title, text]) => addTextSource(store, config, project.id, { title, text }));
  const e = store.list("evidence", project.id);
  const data = [
    ["summary", "研究摘要", "当前更适合推进分阶段验证。样例资料尚不能支持量产或市场规模判断。", 0, "analysis"],
    ["technology", "技术路线", "样品验证尚未完成长循环测试，也没有客户量产定点记录。", 0, "fact"],
    ["market", "市场与需求", "现有资料未提供可核验的市场规模与同年度有效产能，市场判断应暂缓。", 2, "fact"],
    ["competition", "竞争格局", "需要补充同类企业的公开披露与客户验证进度，当前资料不足以比较竞争地位。", 2, "hypothesis"],
    ["strategy", "企业匹配与建议", "建议先开展样品评价与小试复现，再决定是否进入中试；采购意向需要与采购承诺分开记录。", 1, "analysis"],
    ["risks", "风险与验证", "案例企业具备湿法合成与小试经验，但缺少连续量产验证记录。", 1, "fact"]
  ];
  const content = data.map(([sectionId, heading, text, index, kind]) => ({
    sectionId, heading, paragraphs: [{ id: id(), text, kind, evidenceIds: [e[index].id], review: "unreviewed" }],
    gaps: sectionId === "market" ? ["补充真实市场统计口径及对应原文。"] : []
  }));
  const draft = saveDraft(store, project.id, { revision: 1, content });
  snapshot(store, project.id, draft.revision);
  return project;
}
