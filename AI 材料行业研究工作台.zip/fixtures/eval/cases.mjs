export const cases = [
  { name: "合法事实引用", quote: "样品尚未取得量产定点。", text: "样品尚未取得量产定点。", ids: ["e1"], expected: "pass" },
  { name: "未知引用", quote: "样品仍在验证。", text: "样品仍在验证。", ids: ["missing"], expected: "reject" },
  { name: "无引用事实", quote: "样品仍在验证。", text: "已实现量产。", ids: [], expected: "flag" },
  { name: "无依据规模", quote: "未给出市场规模。", text: "市场规模为100亿元。", ids: ["e1"], expected: "flag" },
  { name: "无依据日期", quote: "验证尚未完成。", text: "2028年完成量产。", ids: ["e1"], expected: "flag" },
  { name: "原文数字一致", quote: "样品循环测试记录为120次。", text: "记录为120次。", ids: ["e1"], expected: "pass" },
  { name: "重复引用ID", quote: "项目未量产。", text: "项目未量产。", ids: ["e1", "e1"], expected: "pass" },
  { name: "分析无引用", quote: "缺少客户验证。", text: "建议先补齐验证资料。", ids: [], kind: "analysis", expected: "pass" },
  { name: "结构不合法", quote: "样品测试。", invalid: true, expected: "reject" },
  { name: "数字口径不同需人工审核", quote: "A公司产能为10万吨。", text: "A公司销量为10万吨。", ids: ["e1"], expected: "pass", limitation: "ID和数字检查无法判断产能与销量口径，必须人工审核" }
];
