import { checkOutput } from "../server/model.mjs";
import { cases } from "../fixtures/eval/cases.mjs";
const results = cases.map(c => {
  let actual;
  try {
    const output = checkOutput(c.invalid ? {} : { paragraphs: [{ text: c.text, kind: c.kind || "fact", evidenceIds: c.ids }], gaps: [] }, [{ id: "e1", quote: c.quote }]);
    actual = output.gaps.length ? "flag" : "pass";
  } catch { actual = "reject"; }
  return { name: c.name, expected: c.expected, actual, passed: actual === c.expected, limitation: c.limitation || null };
});
console.log(JSON.stringify({ evaluatedAt: new Date().toISOString(), kind: "offline-validator-regression", realModelCalls: 0, humanEvidenceSupportRate: null, results }, null, 2));
if (results.some(r => !r.passed)) process.exitCode = 1;
