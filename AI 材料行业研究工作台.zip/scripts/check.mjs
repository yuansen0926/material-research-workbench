import { readdirSync, readFileSync, existsSync } from "node:fs";
import { resolve, join } from "node:path";
import { spawnSync } from "node:child_process";
let checked = 0;
for (const folder of ["server", "shared", "ui", "scripts", "tests", "fixtures"]) {
  if (!existsSync(folder)) continue;
  for (const file of readdirSync(folder, { recursive: true })) {
    if (!/\.(mjs|js)$/.test(file)) continue;
    const result = spawnSync(process.execPath, ["--check", join(folder, file)], { encoding: "utf8" });
    if (result.status) { console.error(result.stderr); process.exit(1); }
    checked++;
  }
}
for (const file of ["workbench.mjs"]) {
  const result = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
  if (result.status) { console.error(result.stderr); process.exit(1); } checked++;
}
const app = readFileSync("ui/app.js", "utf8");
const icons = [...app.matchAll(/(?:icon\(|button\([^,\n]*,\s*[^,\n]*,\s*)"([a-z0-9-]+)"/g)].map(match => match[1]);
for (const icon of icons) {
  if (!existsSync(resolve("node_modules/lucide-static/icons", `${icon}.svg`))) throw new Error(`Missing icon: ${icon}`);
}
console.log(`Syntax OK: ${checked} files; icon assets checked.`);
