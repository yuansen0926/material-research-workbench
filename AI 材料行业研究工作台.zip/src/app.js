const STORAGE_KEY = "material-research-generator-v1";

const materials = {
  lmfp: {
    name: "磷酸锰铁锂",
    category: "正极材料",
    thesis: "兼顾磷酸铁锂成本基础和更高电压平台，是正极体系升级中的中期机会。",
    technology: "核心关注锰铁比例、压实密度、循环稳定性和与现有 LFP 产线的兼容性。技术难点在于锰溶出控制、倍率性能和批次一致性。",
    market: "下游需求来自中高续航铁锂车型与储能场景。若电池厂验证顺利，材料企业可通过客户联合开发获得导入窗口。",
    competition: "头部正极企业具备规模和客户优势，新进入者更适合从改性方案、前驱体协同或区域客户切入。",
    strategy: "建议采用小规模中试、客户送样、成本曲线拆解三步推进，避免在需求未验证前重资产扩产。",
    scores: { market: 86, fit: 82, barrier: 66 },
  },
  silicon: {
    name: "硅碳负极",
    category: "负极材料",
    thesis: "快充和高能量密度需求推动硅碳负极进入验证期，但产业化节奏取决于膨胀控制与循环寿命。",
    technology: "核心在纳米硅分散、碳包覆、预锂化和粘结体系。量产评价重点是首次效率、膨胀率、循环保持率和成本。",
    market: "高端动力电池、消费电池和部分快充车型先行导入，中期空间取决于电芯厂平台化应用速度。",
    competition: "石墨龙头、电池厂体系公司和新材料企业共同竞争，客户验证数据是主要壁垒。",
    strategy: "适合作为技术期权布局，通过联合开发或小比例掺混场景建立应用数据。",
    scores: { market: 84, fit: 72, barrier: 78 },
  },
  additive: {
    name: "电解液添加剂",
    category: "电解液材料",
    thesis: "添加剂是性能微创新和客户定制的重要抓手，适合技术型材料企业做差异化切入。",
    technology: "重点关注成膜稳定性、高压体系适配、低温性能、安全性和配方协同。研发评价依赖电芯级验证。",
    market: "需求跟随高电压、快充、储能和低温场景变化，单品规模有限但毛利弹性较强。",
    competition: "竞争集中在配方理解、客户响应和专利布局，头部企业拥有客户认证优势。",
    strategy: "建议围绕 2-3 个细分场景建立样品库，优先绑定研发型客户共同验证。",
    scores: { market: 73, fit: 80, barrier: 62 },
  },
  separator: {
    name: "隔膜",
    category: "电池结构件",
    thesis: "隔膜仍是电池安全关键材料，但行业重资产属性强，规模壁垒和客户认证壁垒较高。",
    technology: "干法、湿法、涂覆和基膜一致性是关键。制造环节对设备、良率和过程控制要求高。",
    market: "需求随动力和储能电池出货增长，但价格竞争和扩产节奏会压缩利润空间。",
    competition: "龙头企业规模优势显著，新进入者需要差异化涂覆或区域配套能力。",
    strategy: "对非隔膜基础企业而言，不建议作为主航道，可观察涂覆材料或设备协同机会。",
    scores: { market: 68, fit: 42, barrier: 82 },
  },
  copper: {
    name: "复合集流体/铜箔",
    category: "集流体",
    thesis: "铜箔和复合集流体受轻量化、安全和成本驱动，但产业化节奏仍取决于设备、良率和电池厂导入。",
    technology: "关注厚度控制、抗拉强度、穿刺安全、镀层一致性和卷绕适配。复合集流体还需要验证长期可靠性。",
    market: "传统铜箔需求确定性较强，复合集流体具备成长弹性但短期放量不确定。",
    competition: "铜箔企业、膜材企业和电池厂生态公司共同参与，设备和客户验证是核心变量。",
    strategy: "建议以跟踪和小比例合作为主，避免过早押注单一路线。",
    scores: { market: 66, fit: 58, barrier: 70 },
  },
  recycle: {
    name: "电池回收",
    category: "循环经济",
    thesis: "回收业务兼具资源安全、政策合规和成本对冲价值，是材料企业构建闭环能力的战略期权。",
    technology: "湿法回收、梯次利用、黑粉处理和金属回收率是关键，合规资质和渠道控制同样重要。",
    market: "退役电池规模逐步释放，短期受价格周期影响，长期受政策和供应链安全驱动。",
    competition: "电池厂、材料厂、第三方回收企业和地方平台共同参与，渠道与资质决定先发优势。",
    strategy: "建议通过合作试点、区域回收网络和客户闭环服务切入，不宜单独大规模铺开。",
    scores: { market: 78, fit: 74, barrier: 64 },
  },
  resin: {
    name: "电子树脂",
    category: "电子化学品",
    thesis: "电子树脂连接材料、电子和先进封装场景，能体现材料技术与下游应用研究能力。",
    technology: "重点关注介电性能、耐热性、低吸水率、纯度控制和配方体系。不同下游场景对树脂指标要求差异较大。",
    market: "PCB、显示面板、传统封装和先进封装共同构成需求来源，国产替代和高端电子材料升级是主要逻辑。",
    competition: "海外厂商在高端体系占优，国内企业通过细分应用、客户验证和成本响应建立突破机会。",
    strategy: "建议按应用场景拆分研究，不用一个口径判断全部电子树脂市场。",
    scores: { market: 76, fit: 86, barrier: 72 },
  },
};

const authoritativeSources = [
  {
    title: "IEA - Global EV Outlook 2026: Electric vehicle batteries",
    type: "国际机构报告",
    date: "2026",
    url: "https://www.iea.org/reports/global-ev-outlook-2026/electric-vehicle-batteries",
    note: "用于判断电动汽车电池需求、关键矿产需求和全球电池产业趋势。",
    grade: "A",
  },
  {
    title: "IEA - Batteries and Secure Energy Transitions",
    type: "国际机构专题报告",
    date: "2024-04",
    url: "https://www.iea.org/reports/batteries-and-secure-energy-transitions",
    note: "覆盖电池技术进步、制造、关键矿产、回收和能源转型约束。",
    grade: "A",
  },
  {
    title: "USGS - Mineral Commodity Summaries 2026",
    type: "政府矿产数据",
    date: "2026-02",
    url: "https://pubs.usgs.gov/publication/mcs2026",
    note: "用于核对锂、石墨、镍、钴、铜等关键矿产的供给、储量和统计口径。",
    grade: "A",
  },
  {
    title: "中国政府网 - China revises guidelines for lithium-ion battery industry",
    type: "政策与规范",
    date: "2024-06",
    url: "https://english.www.gov.cn/news/202406/19/content_WS6672a076c6d0868f4e8e851d.html",
    note: "用于识别中国锂电池行业规范、技术质量、安全环保和产业政策约束。",
    grade: "A-",
  },
];

const reportFields = [
  ["executiveSummary", "高管摘要", "large"],
  ["technology", "技术路线与性能指标", ""],
  ["applications", "应用场景与客户导入", ""],
  ["market", "市场空间与需求驱动", ""],
  ["supply", "供给格局与产能节奏", ""],
  ["competition", "竞争格局与玩家类型", ""],
  ["costPrice", "价格、成本与盈利弹性", ""],
  ["policy", "政策、合规与全球供应链", ""],
  ["companyFit", "企业匹配度评估", ""],
  ["strategy", "战略建议与进入路径", "large"],
  ["milestones", "后续验证里程碑", ""],
];

const defaultState = {
  materialId: "lmfp",
  customMaterial: "",
  goal: "判断未来 3 年该材料赛道的战略进入价值，并形成面向管理层的行研报告。",
  company: "具备湿法合成、客户联合验证和成本管控经验的制造业材料企业",
  capability: "材料合成、连续化生产、质量控制、客户送样、价格跟踪",
  lens: "战略进入",
  depth: "标准分析版",
  notes: "请突出技术路线、市场空间、竞争格局、风险和行动建议。",
  weights: { market: 45, fit: 40, barrier: 15 },
  report: null,
  evidence: [],
  searchResults: [],
  researchPack: [],
  searchQuery: "",
  searchScope: ["技术路线", "市场空间", "竞争格局", "政策合规"],
  enabledSections: reportFields.map(([key]) => key),
  aiSource: "未生成",
  stage: "compose",
};

let state = loadState();
let isGenerating = false;
let isSearching = false;

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    if (!saved) return structuredClone(defaultState);
    const merged = { ...defaultState, ...saved, weights: { ...defaultState.weights, ...saved.weights } };
    if (!saved.stage && saved.report) merged.stage = "result";
    return merged;
  } catch {
    return structuredClone(defaultState);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function material() {
  if (state.materialId === "custom") {
    const name = state.customMaterial.trim() || "自定义材料";
    return {
      name,
      category: "自定义材料",
      thesis: "自定义材料将优先通过联网资料包生成分析，需要结合权威来源和人工复核。",
      technology: `${name}的技术路线需要结合具体化学体系、工艺路线、性能指标和下游客户认证要求进一步拆解。`,
      market: `${name}的市场判断应通过下游应用、渗透率、价格口径和竞争格局交叉验证。`,
      competition: `${name}的竞争格局需要通过上市公司公告、行业研报、协会数据和客户验证信息确认。`,
      strategy: `建议先建立${name}的权威来源库、竞品清单和客户验证问题表，再判断进入路径。`,
      scores: { market: 70, fit: 60, barrier: 65 },
    };
  }
  return materials[state.materialId] || materials.lmfp;
}

function materialName() {
  return material().name;
}

function isWeakSource(item = {}) {
  const text = `${item.title || ""} ${item.url || ""} ${item.snippet || ""} ${item.note || ""}`;
  return /百度百科|知乎|小红书|贴吧|Wikiwand|wikipedia|百科|京东|淘宝|商城|固态硬盘|SSD|NVMe/i.test(text);
}

function escapeHtml(value = "") {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function localReport() {
  const m = material();
  const topRanks = calculateRanks().slice(0, 3).map((item) => item.name).join("、");
  return {
    title: `${m.name}行业研究报告`,
    executiveSummary: [
      `${m.name}属于${m.category}方向，是制造业材料企业在新能源与高端制造链条中可以重点观察的细分赛道。${m.thesis}`,
      `本报告围绕“${state.goal}”展开，采用“技术可行性、市场吸引力、竞争强度、企业匹配度、进入节奏”五维框架，输出面向战略岗和管理层的判断。`,
      `基于当前参数，系统建议将${m.name}作为核心分析对象，并把${topRanks}列为横向比较赛道。结论不是直接给出投资决策，而是帮助识别应继续验证的关键问题。`
    ].join("\n\n"),
    technology: [
      m.technology,
      "技术判断不只看材料概念是否热门，还要拆到量产指标：稳定性、一致性、良率、设备适配、客户验证数据和安全边界。这一层能体现材料机理与商业化约束，而不是只停留在市场叙事。",
      `对${m.name}而言，建议把技术问题拆成三个表：核心性能指标、量产放大约束、与现有工艺的复用程度。`
    ].join("\n\n"),
    applications: [
      "应用端需要区分动力电池、储能、电动工具、消费电池和海外客户的不同导入节奏。动力场景更关注能量密度、安全和车规验证，储能场景更关注循环寿命、成本和长期稳定性。",
      `${m.name}的商业化判断应优先绑定具体客户场景，而不是单独估算材料总市场。若客户验证和配方适配没有形成闭环，市场空间容易被高估。`
    ].join("\n\n"),
    market: [
      m.market,
      "需求分析建议采用“下游装机/出货 - 单位材料消耗 - 技术渗透率 - 价格假设”的链条，而不是直接引用单一市场规模数字。这样更容易解释假设来源，也方便后续复核推导过程。",
      "短期看客户导入和价格周期，中期看技术路线渗透，长期看能源转型、供应链安全和回收闭环。"
    ].join("\n\n"),
    supply: [
      "供给端需要同时看名义产能、有效产能、客户认证产能和可盈利产能。材料行业常见问题是公告产能很大，但真正能稳定供货并进入核心客户体系的产能有限。",
      `对${m.name}，应重点跟踪头部企业扩产节奏、关键设备交期、原料保障、库存变化和客户锁量情况。`
    ].join("\n\n"),
    competition: [
      m.competition,
      "竞争玩家可分为四类：既有材料龙头、垂直一体化电池厂、技术创业公司、区域配套型企业。战略分析的重点不是罗列公司，而是判断每类玩家的优势来源和可被突破的位置。",
      "如果企业没有规模优势，就应避免与龙头进行同质化产能竞争，转向细分场景、客户共研、工艺优化或配方差异化。"
    ].join("\n\n"),
    costPrice: [
      "价格和成本部分应拆分为原料价格、加工费用、良率、能耗、折旧和客户议价。材料价格波动会直接影响短期利润，但战略价值更取决于企业能否建立稳定客户、稳定工艺和持续降本能力。",
      "建议在报告中同时展示基准、乐观、压力三种情景，避免只给单点预测。若引用价格数据，需要标明现货价、长协价、含税/不含税和地区口径。"
    ].join("\n\n"),
    policy: [
      "政策与合规关注四类变量：产业规范、安全环保、碳足迹与回收责任、海外本地化和供应链审查。对于进入海外客户链条的材料企业，合规能力可能从成本项变成准入门槛。",
      "系统将 IEA、USGS 和中国政府/工信体系信息作为优先参考来源，体现报告引用的权威性和可复核性。"
    ].join("\n\n"),
    companyFit: [
      `企业背景：${state.company}。现有能力：${state.capability}。`,
      `从匹配度看，${m.name}是否适合进入，取决于三件事：现有工艺能否复用、客户资源能否转化为验证机会、资本开支是否能分阶段投入。`,
      "如果三项条件同时满足，可以进入中试和客户联合验证；如果只满足其中一项，更适合作为研究储备或合作跟踪。"
    ].join("\n\n"),
    strategy: [
      `对${state.company}而言，${m.strategy}`,
      "建议采用三阶段路径：第一阶段完成公开资料、价格、竞品和客户需求验证；第二阶段启动样品或小试，形成性能和成本对照；第三阶段再决定自建产线、合资合作、并购参股或放弃。",
      "管理层汇报时可以把结论压缩为一个判断：当前不是问“要不要立刻重投入”，而是问“是否值得用低成本方式买入一个战略观察窗口”。"
    ].join("\n\n"),
    milestones: [
      "0-1 个月：完成技术指标表、竞品数据库和权威来源引用库。",
      "1-3 个月：访谈潜在客户或专家，验证真实痛点和导入门槛。",
      "3-6 个月：形成样品、小试或合作方案，建立成本敏感性模型。",
      "6 个月后：根据客户反馈和财务测算决定是否进入中试或投资谈判。"
    ].join("\n"),
    risks: [
      "下游客户验证周期可能长于预期。",
      "原材料价格、供需周期和竞争扩产可能影响盈利测算。",
      "技术路线变化可能导致设备或工艺投入无法充分复用。",
      "公开资料存在滞后和口径差异，关键结论需要用企业访谈或一手数据复核。",
    ],
    evidence: authoritativeSources,
  };
}

function normalizedReport(report) {
  const fallback = localReport();
  return {
    title: report?.title || fallback.title,
    executiveSummary: report?.executiveSummary || fallback.executiveSummary,
    technology: report?.technology || fallback.technology,
    applications: report?.applications || fallback.applications,
    market: report?.market || fallback.market,
    supply: report?.supply || fallback.supply,
    competition: report?.competition || fallback.competition,
    costPrice: report?.costPrice || fallback.costPrice,
    policy: report?.policy || fallback.policy,
    companyFit: report?.companyFit || fallback.companyFit,
    strategy: report?.strategy || fallback.strategy,
    milestones: report?.milestones || fallback.milestones,
    risks: Array.isArray(report?.risks) && report.risks.length ? report.risks : fallback.risks,
    evidence: Array.isArray(report?.evidence) && report.evidence.length ? report.evidence : fallback.evidence,
  };
}

function calculateRanks() {
  const weights = state.weights;
  return Object.entries(materials)
    .map(([id, item]) => {
      const score = (
        item.scores.market * weights.market +
        item.scores.fit * weights.fit -
        item.scores.barrier * weights.barrier * .45
      ) / 100;
      return { id, ...item, score: Math.round(score * 10) / 10 };
    })
    .sort((a, b) => b.score - a.score);
}

function reportWordCount() {
  const report = state.report ? normalizedReport(state.report) : null;
  if (!report) return 0;
  return [
    report.title,
    report.executiveSummary,
    report.technology,
    report.market,
    report.competition,
    report.strategy,
    ...report.risks,
  ].join("").length;
}

function render() {
  const m = material();
  const report = state.report ? normalizedReport(state.report) : localReport();
  const ranks = calculateRanks();
  const selectedRank = ranks.findIndex((item) => item.id === state.materialId) + 1;
  state.searchResults = (state.searchResults || []).filter((item) => !isWeakSource(item));
  state.evidence = (state.evidence || []).filter((item) => !isWeakSource(item));
  const evidence = (state.evidence.length ? state.evidence : report.evidence).filter((item) => !isWeakSource(item));
  const hasResult = state.stage === "result";

  document.getElementById("app").innerHTML = `
    <div class="layout">
      <aside class="sidebar">
        <div class="brand">
          <div class="brand-mark">AI</div>
          <div>
            <h1>材料行研报告生成器</h1>
            <p>制造业材料研究与战略分析</p>
          </div>
        </div>
        <nav class="nav" aria-label="页面导航">
          <a class="${!hasResult ? "active" : ""}" href="#compose"><span class="nav-icon">01</span><span>输入需求</span></a>
          <a class="${hasResult ? "active" : ""}" href="#result"><span class="nav-icon">02</span><span>分析结果</span></a>
          <a href="#evidence"><span class="nav-icon">03</span><span>来源资料</span></a>
          <a href="#report"><span class="nav-icon">04</span><span>报告输出</span></a>
        </nav>
        <p class="sidebar-note">输入材料方向和研究要求，系统检索公开资料并生成可编辑报告。</p>
      </aside>

      <main class="main">
        <header class="topbar">
          <div>
            <h2>${hasResult ? `${escapeHtml(m.name)}分析结果` : "新建材料研究任务"}</h2>
            <p>${hasResult ? "资料包、战略框架与报告正文已生成，可继续修改或导出。" : "像提交研究委托一样输入你的问题和背景。"}</p>
          </div>
          <div class="topbar-actions">
            ${hasResult ? `<button class="btn" data-action="back-compose">修改需求</button>` : ""}
            <button class="btn" data-action="save">保存</button>
            <button class="btn" data-action="export-md" ${hasResult ? "" : "disabled"}>导出 MD</button>
            <button class="btn" data-action="export-doc" ${hasResult ? "" : "disabled"}>导出 DOC</button>
            <button class="btn" data-action="print" ${hasResult ? "" : "disabled"}>打印</button>
          </div>
        </header>

        <div class="content">
          ${hasResult ? renderResultView(m, report, ranks, selectedRank, evidence) : renderComposeView()}
        </div>
      </main>
    </div>
    <div id="toast" class="toast hidden"></div>
  `;
}

function renderComposeView() {
  return `
    <section class="composer" id="compose">
      <div class="composer-card">
        <div class="composer-title">
          <h2>你想研究哪一种制造业材料？</h2>
          <p>输入材料名称、研究目标和企业背景，系统会先检索资料，再生成技术、市场、竞争、风险和战略建议。</p>
        </div>

        <div class="prompt-box controls-only">
          <textarea id="goal" data-field="goal" placeholder="例如：请分析固态电解质赛道，判断一家具备无机粉体合成和客户验证能力的材料企业是否适合进入，并输出管理层可读的行业研究报告。">${escapeHtml(state.goal)}</textarea>
          <div class="prompt-tools">
            <div class="chip-row">
              <select id="materialId" data-field="materialId" aria-label="材料方向">
                ${Object.entries(materials).map(([id, item]) => `<option value="${id}" ${id === state.materialId ? "selected" : ""}>${item.name}</option>`).join("")}
                <option value="custom" ${state.materialId === "custom" ? "selected" : ""}>自定义材料</option>
              </select>
              <select id="lens" data-field="lens" aria-label="分析视角">
                ${["战略进入", "投资判断", "市场研究", "技术商业化"].map((item) => `<option ${item === state.lens ? "selected" : ""}>${item}</option>`).join("")}
              </select>
            </div>
            <button class="btn primary" data-action="generate" ${isGenerating ? "disabled" : ""}>${isGenerating ? "正在研究..." : "开始生成"}</button>
          </div>
        </div>

        <div class="section controls-only">
          <div class="control-grid">
            <div class="field">
              <label for="customMaterial">材料名称</label>
              <input id="customMaterial" data-field="customMaterial" value="${escapeHtml(state.customMaterial)}" placeholder="选择自定义材料时填写">
            </div>
            <div class="field">
              <label for="company">企业背景</label>
              <input id="company" data-field="company" value="${escapeHtml(state.company)}">
            </div>
            <div class="field full">
              <label for="capability">现有能力</label>
              <textarea id="capability" data-field="capability">${escapeHtml(state.capability)}</textarea>
            </div>
            <div class="field full">
              <label for="notes">补充要求</label>
              <textarea id="notes" data-field="notes">${escapeHtml(state.notes)}</textarea>
            </div>
            <div class="field full">
              <label>报告模块</label>
              <div class="check-grid">
                ${reportFields.map(([key, label]) => `
                  <label class="check-tile">
                    <input type="checkbox" data-section-toggle="${key}" ${state.enabledSections.includes(key) ? "checked" : ""}>
                    <span>${escapeHtml(label)}</span>
                  </label>
                `).join("")}
              </div>
            </div>
          </div>
        </div>

        <div class="stepper">
          <div class="step active"><strong>1. 输入研究委托</strong><span>材料、目标、企业能力</span></div>
          <div class="step"><strong>2. 检索资料包</strong><span>公开资料与权威来源</span></div>
          <div class="step"><strong>3. 输出报告</strong><span>分析框架与正文导出</span></div>
        </div>
      </div>
    </section>
  `;
}

function renderResultView(m, report, ranks, selectedRank, evidence) {
  return `
    <section class="section" id="result">
      <div class="section-header">
        <div>
          <h3>${escapeHtml(report.title)}</h3>
          <p>${escapeHtml(m.thesis)}</p>
        </div>
        <span class="badge green">已生成</span>
      </div>
      <div class="grid cols-4">
        <div class="card metric"><span>市场吸引力</span><strong>${m.scores.market}</strong><div class="progress"><i style="width:${m.scores.market}%"></i></div></div>
        <div class="card metric"><span>企业匹配度</span><strong>${m.scores.fit}</strong><div class="progress"><i style="width:${m.scores.fit}%"></i></div></div>
        <div class="card metric"><span>进入壁垒</span><strong>${m.scores.barrier}</strong><div class="progress"><i style="width:${m.scores.barrier}%"></i></div></div>
        <div class="card metric"><span>资料来源</span><strong>${state.researchPack?.length || evidence.length}</strong><span class="muted">报告生成依据</span></div>
      </div>
    </section>

    <div class="result-grid">
      <div class="grid">
        <div class="brief">
          <h3>研究委托</h3>
          <p>${escapeHtml(state.goal)}</p>
        </div>
        ${renderEvidence(evidence)}
        ${renderMatrix(ranks)}
      </div>
      <div class="grid">
        ${renderReport(report)}
        <div class="chat-dock controls-only">
          <textarea id="notes" data-field="notes" placeholder="继续补充要求，例如：更偏投资视角、补充竞争对手、把建议写得更谨慎。">${escapeHtml(state.notes)}</textarea>
          <div class="inline-actions" style="margin-top: 10px;">
            <button class="btn primary" data-action="generate" ${isGenerating ? "disabled" : ""}>${isGenerating ? "正在更新..." : "按补充要求重新生成"}</button>
            <button class="btn" data-action="back-compose">回到输入页</button>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderMatrix(ranks) {
  const buckets = {
    star: ranks.filter((item) => item.scores.market >= 75 && item.scores.fit >= 75),
    option: ranks.filter((item) => item.scores.market >= 75 && item.scores.fit < 75),
    cash: ranks.filter((item) => item.scores.market < 75 && item.scores.fit >= 75),
    watch: ranks.filter((item) => item.scores.market < 75 && item.scores.fit < 75),
  };
  const renderBucket = (items) => items.length
    ? items.map((item) => `<div class="lane-item"><strong>${escapeHtml(item.name)}</strong><span class="score">${item.score}</span></div>`).join("")
    : `<p>暂无材料落入该象限。</p>`;
  return `
    <section class="section" id="matrix">
      <div class="section-header">
        <div>
          <h3>赛道战略优先级</h3>
          <p>调整权重后，排序会即时更新；象限图采用卡片排布，避免文字和图形重叠。</p>
        </div>
        <span class="badge blue">动态评分</span>
      </div>
      <div class="split">
        <div class="matrix-board" aria-label="材料赛道优先级象限图">
          <div class="quadrant highlight">
            <h4>优先投入：高吸引力 / 高匹配</h4>
            <p>适合进入客户验证或中试方案。</p>
            ${renderBucket(buckets.star)}
          </div>
          <div class="quadrant">
            <h4>技术期权：高吸引力 / 待补能力</h4>
            <p>适合跟踪、合作或小比例试点。</p>
            ${renderBucket(buckets.option)}
          </div>
          <div class="quadrant">
            <h4>能力延展：中低吸引力 / 高匹配</h4>
            <p>适合作为客户维护或现金流补充。</p>
            ${renderBucket(buckets.cash)}
          </div>
          <div class="quadrant">
            <h4>谨慎观察：中低吸引力 / 待补能力</h4>
            <p>暂不作为主航道。</p>
            ${renderBucket(buckets.watch)}
          </div>
        </div>
        <div class="card controls-only">
          <p class="kicker">评分权重</p>
          ${[
            ["market", "市场吸引力"],
            ["fit", "企业匹配度"],
            ["barrier", "进入壁垒惩罚"],
          ].map(([key, label]) => `
            <div class="field" style="margin-bottom: 12px;">
              <label for="weight-${key}">${label}：${state.weights[key]}%</label>
              <input id="weight-${key}" type="range" min="0" max="70" value="${state.weights[key]}" data-weight="${key}">
            </div>
          `).join("")}
          <div class="table-wrap">
            <table>
              <thead><tr><th>排名</th><th>材料</th><th>综合分</th></tr></thead>
              <tbody>
                ${ranks.map((item, index) => `<tr><td>${index + 1}</td><td>${escapeHtml(item.name)}</td><td>${item.score}</td></tr>`).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  `;
}

function renderEvidence(evidence) {
  const canRemoveEvidence = state.evidence.length > 0;
  return `
    <section class="section" id="evidence">
      <div class="section-header">
        <div>
          <h3>证据与资料</h3>
          <p>可用公开搜索补充资料，也可以保留 AI 或本地生成的证据卡片。</p>
        </div>
        <span class="badge green">${evidence.length} 条证据</span>
      </div>
      <div class="split">
        <div class="card controls-only">
          <div class="field">
            <label for="searchQuery">公开资料搜索</label>
            <input id="searchQuery" data-field="searchQuery" value="${escapeHtml(state.searchQuery)}" placeholder="输入任意检索式，例如：固态电解质 产业化 研报">
          </div>
          <div class="field" style="margin-top: 12px;">
            <label>检索方向</label>
            <div class="check-grid">
              ${["技术路线", "市场空间", "竞争格局", "价格供需", "政策合规", "公司公告"].map((scope) => `
                <label class="check-tile">
                  <input type="checkbox" data-scope-toggle="${scope}" ${state.searchScope.includes(scope) ? "checked" : ""}>
                  <span>${scope}</span>
                </label>
              `).join("")}
            </div>
          </div>
          <div class="inline-actions" style="margin-top: 12px;">
            <button class="btn" data-action="search" ${isSearching ? "disabled" : ""}>${isSearching ? "搜索中..." : "搜索公开资料"}</button>
          </div>
          <div class="grid" style="margin-top: 12px;">
            ${state.searchResults.length ? state.searchResults.map((item, index) => `
              <div class="report-block">
                <h4>${escapeHtml(item.title)}</h4>
                <div class="source-meta">
                  <span class="pill blue">${escapeHtml(item.type || "公开搜索")}</span>
                  <span class="pill green">等级 ${escapeHtml(item.grade || "B")}</span>
                  ${item.date ? `<span class="pill">${escapeHtml(item.date)}</span>` : ""}
                </div>
                <p class="muted">${escapeHtml(item.snippet || "无摘要")}</p>
                <div class="inline-actions">
                  <a class="btn" href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">打开来源</a>
                  <button class="btn" data-action="add-search-evidence" data-index="${index}">加入证据</button>
                </div>
              </div>
            `).join("") : `<p class="muted">尚未搜索。生成报告后会先显示报告自带证据。</p>`}
          </div>
          <div class="field" style="margin-top: 14px;">
            <label for="sourceUrl">手动加入权威来源 URL</label>
            <input id="sourceUrl" placeholder="例如 IEA、USGS、政府网、上市公司公告链接">
          </div>
          <div class="inline-actions" style="margin-top: 12px;">
            <button class="btn" data-action="fetch-source">抓取并加入证据</button>
          </div>
        </div>
          <div class="grid">
            ${evidence.map((item, index) => `
            <div class="card source-card">
              <div class="source-meta">
                <span class="pill blue">${escapeHtml(item.type || "资料")}</span>
                <span class="pill green">等级 ${escapeHtml(item.grade || "B+")}</span>
                ${item.date ? `<span class="pill">${escapeHtml(item.date)}</span>` : ""}
              </div>
              <strong>${escapeHtml(item.title || "未命名证据")}</strong>
              <p class="muted">${escapeHtml(item.note || item.snippet || "暂无摘要")}</p>
              ${item.url ? `<a class="pill blue" href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">查看链接</a>` : ""}
              ${canRemoveEvidence ? `<button class="btn danger" data-action="remove-evidence" data-index="${index}" style="margin-top: 10px;">移除</button>` : ""}
            </div>
          `).join("")}
        </div>
      </div>
    </section>
  `;
}

function renderReport(report) {
  const activeFields = reportFields.filter(([key]) => state.enabledSections.includes(key));
  return `
    <section class="section" id="report">
      <div class="section-header">
        <div>
          <h3>行业研究报告</h3>
          <p>按标准报告结构排版，正文可修改，导出内容以这里为准。</p>
        </div>
        <span class="badge amber">可编辑</span>
      </div>
      <div class="document">
        <div class="doc-cover">
          <p class="kicker">Material Industry Research</p>
          <h3>${escapeHtml(report.title)}</h3>
          <p class="muted">研究对象：${escapeHtml(materialName())}　分析视角：${escapeHtml(state.lens)}　来源数量：${state.researchPack?.length || report.evidence.length}</p>
        </div>
        <div class="toc">
          ${activeFields.map(([key, label], index) => `<a href="#report-${key}"><span>${index + 1}. ${escapeHtml(label)}</span><span>p.${index + 1}</span></a>`).join("")}
          <a href="#report-risks"><span>${activeFields.length + 1}. 关键风险</span><span>p.${activeFields.length + 1}</span></a>
        </div>
        <div class="report">
        <div class="field">
          <label for="reportTitle">报告标题</label>
          <input id="reportTitle" data-report-field="title" value="${escapeHtml(report.title)}">
        </div>
        ${activeFields.map(([key, label, size]) => `
          <div class="report-block ${size}" id="report-${key}">
            <h4>${label}</h4>
            <textarea data-report-field="${key}">${escapeHtml(report[key])}</textarea>
          </div>
        `).join("")}
        <div class="report-block" id="report-risks">
          <h4>关键风险</h4>
          <textarea data-report-field="risks">${escapeHtml(report.risks.join("\n"))}</textarea>
        </div>
        </div>
      </div>
    </section>
  `;
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.add("hidden"), 2600);
}

function collectForm() {
  document.querySelectorAll("[data-field]").forEach((input) => {
    state[input.dataset.field] = input.value;
  });
}

function collectReport() {
  if (!state.report) state.report = localReport();
  document.querySelectorAll("[data-report-field]").forEach((input) => {
    const key = input.dataset.reportField;
    state.report[key] = key === "risks"
      ? input.value.split("\n").map((item) => item.trim()).filter(Boolean)
      : input.value;
  });
}

async function generateWithAi() {
  collectForm();
  isGenerating = true;
  render();
  try {
    const response = await fetch("/api/generate-report", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        material: material().name,
        goal: state.goal,
        company: state.company,
        capability: state.capability,
        lens: state.lens,
        depth: state.depth,
        notes: state.notes,
      }),
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || "生成失败");
    state.report = normalizedReport(payload.report);
    state.researchPack = payload.researchPack || [];
    state.evidence = (state.report.evidence || state.researchPack || []).filter((item) => !isWeakSource(item));
    state.aiSource = payload.source === "openai" ? "OpenAI + 联网资料包" : "联网资料包";
    state.stage = "result";
    saveState();
    showToast(payload.message || "报告已生成");
  } catch (error) {
    state.report = localReport();
    state.evidence = state.report.evidence.filter((item) => !isWeakSource(item));
    state.aiSource = "离线样例";
    state.stage = "result";
    saveState();
    showToast(`AI 生成不可用，已切换本地样例：${error.message}`);
  } finally {
    isGenerating = false;
    render();
  }
}

async function searchSources() {
  const input = document.getElementById("searchQuery");
  state.searchQuery = input?.value.trim() || state.searchQuery || materialName();
  const scopes = state.searchScope.length ? state.searchScope.join(" ") : "行业研究";
  const query = `${materialName()} ${state.searchQuery} ${scopes}`;
  isSearching = true;
  render();
  try {
    const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || "搜索失败");
    state.searchResults = (payload.results || []).filter((item) => !isWeakSource(item));
    state.searchQuery = input?.value.trim() || state.searchQuery;
    saveState();
    showToast(state.searchResults.length ? "搜索结果已更新" : "未找到可展示结果");
  } catch (error) {
    showToast(`公开搜索暂不可用：${error.message}`);
  } finally {
    isSearching = false;
    render();
  }
}

async function fetchSourceByUrl() {
  const input = document.getElementById("sourceUrl");
  const url = input?.value.trim();
  if (!url) {
    showToast("请输入来源 URL");
    return;
  }
  try {
    const response = await fetch("/api/fetch-source", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || "抓取失败");
    state.evidence = [...state.evidence, payload.source].filter((item) => !isWeakSource(item));
    saveState();
    render();
    showToast("来源已加入证据库");
  } catch (error) {
    showToast(`来源抓取失败：${error.message}`);
  }
}

function exportMarkdown() {
  collectReport();
  const report = normalizedReport(state.report);
  const activeFields = reportFields.filter(([key]) => state.enabledSections.includes(key));
  const md = [
    `# ${report.title}`,
    "",
    ...activeFields.flatMap(([key, label]) => [`## ${label}`, report[key], ""]),
    "## 关键风险",
    ...report.risks.map((risk) => `- ${risk}`),
    "",
    "## 证据与资料",
    ...(state.evidence.length ? state.evidence : report.evidence).filter((item) => !isWeakSource(item)).map((item) => `- ${item.title || "资料"}（${item.type || "来源"}，等级 ${item.grade || "B+"}）：${item.note || item.snippet || ""}${item.url ? ` ${item.url}` : ""}`),
  ].join("\n");
  download(`${report.title}.md`, md, "text/markdown;charset=utf-8");
}

function exportDoc() {
  collectReport();
  const report = normalizedReport(state.report);
  const activeFields = reportFields.filter(([key]) => state.enabledSections.includes(key));
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(report.title)}</title></head><body>
    <h1>${escapeHtml(report.title)}</h1>
    ${activeFields.map(([key, label]) => `<h2>${escapeHtml(label)}</h2><p>${escapeHtml(report[key]).replace(/\n/g, "<br>")}</p>`).join("")}
    <h2>关键风险</h2><ul>${report.risks.map((risk) => `<li>${escapeHtml(risk)}</li>`).join("")}</ul>
    <h2>证据与资料</h2><ul>${(state.evidence.length ? state.evidence : report.evidence).filter((item) => !isWeakSource(item)).map((item) => `<li>${escapeHtml(item.title || "资料")}（${escapeHtml(item.type || "来源")}，等级 ${escapeHtml(item.grade || "B+")}）${item.url ? ` - ${escapeHtml(item.url)}` : ""}</li>`).join("")}</ul>
  </body></html>`;
  download(`${report.title}.doc`, html, "application/msword;charset=utf-8");
}

function download(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename.replace(/[\\/:*?"<>|]/g, "_");
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

document.addEventListener("input", (event) => {
  const target = event.target;
  if (target.matches("[data-field]")) {
    state[target.dataset.field] = target.value;
    saveState();
  }
  if (target.matches("[data-weight]")) {
    state.weights[target.dataset.weight] = Number(target.value);
    saveState();
    render();
  }
  if (target.matches("[data-report-field]")) {
    collectReport();
    saveState();
  }
});

document.addEventListener("change", (event) => {
  const target = event.target;
  if (target.matches("[data-field]")) {
    state[target.dataset.field] = target.value;
    saveState();
    if (target.dataset.field === "materialId" || target.dataset.field === "lens") render();
  }
  if (target.matches("[data-section-toggle]")) {
    const key = target.dataset.sectionToggle;
    state.enabledSections = target.checked
      ? [...new Set([...state.enabledSections, key])]
      : state.enabledSections.filter((item) => item !== key);
    if (!state.enabledSections.length) state.enabledSections = ["executiveSummary"];
    saveState();
    render();
  }
  if (target.matches("[data-scope-toggle]")) {
    const scope = target.dataset.scopeToggle;
    state.searchScope = target.checked
      ? [...new Set([...state.searchScope, scope])]
      : state.searchScope.filter((item) => item !== scope);
    saveState();
    render();
  }
});

document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const action = button.dataset.action;
  if (action === "generate") generateWithAi();
  if (action === "local-generate") {
    collectForm();
    state.report = localReport();
    state.evidence = state.report.evidence.filter((item) => !isWeakSource(item));
    state.researchPack = [];
    state.aiSource = "快速样例";
    state.stage = "result";
    saveState();
    render();
    showToast("本地样例报告已生成");
  }
  if (action === "save") {
    collectForm();
    collectReport();
    saveState();
    showToast("已保存到浏览器本地");
  }
  if (action === "reset") {
    state = structuredClone(defaultState);
    localStorage.removeItem(STORAGE_KEY);
    render();
    showToast("已恢复默认数据");
  }
  if (action === "export-md") exportMarkdown();
  if (action === "export-doc") exportDoc();
  if (action === "print") window.print();
  if (action === "back-compose") {
    collectForm();
    state.stage = "compose";
    saveState();
    render();
  }
  if (action === "search") searchSources();
  if (action === "fetch-source") fetchSourceByUrl();
  if (action === "add-search-evidence") {
    const item = state.searchResults[Number(button.dataset.index)];
    if (item) {
      state.evidence = [...state.evidence, { ...item, note: item.snippet }].filter((source) => !isWeakSource(source));
      saveState();
      render();
      showToast("已加入证据库");
    }
  }
  if (action === "remove-evidence") {
    state.evidence.splice(Number(button.dataset.index), 1);
    saveState();
    render();
    showToast("证据已移除");
  }
});

render();
