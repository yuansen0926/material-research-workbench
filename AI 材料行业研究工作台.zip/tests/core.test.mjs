import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { openStore } from "../server/db.mjs";
import { createProject, saveDraft, snapshot, updateProject } from "../server/projects.mjs";
import { addTextSource, extractHtml, isPublicAddress, safeFetch, parseSearchFeed, addSource } from "../server/sources.mjs";
import { checkOutput, generateSection } from "../server/model.mjs";
import { createWorkflow } from "../server/workflow.mjs";
import { createHttpServer } from "../server/http.mjs";
import { seedDemo } from "../fixtures/demo.mjs";
import { markdown } from "../server/exports.mjs";
import { acquireInstance } from "../server/instance.mjs";

function fixture(t) {
  const directory = mkdtempSync(join(tmpdir(), "material-workbench-test-"));
  const store = openStore(directory);
  const config = { dataDir: directory, port: 0, apiKey: "", model: "test-model", maxCalls: 16, maxMinutes: 1 };
  t.after(() => { store.close(); rmSync(directory, { recursive: true, force: true }); });
  return { store, config };
}
const input = { title: "测试研究", material: "测试材料", question: "验证证据与结论", enabledSections: ["summary", "technology"] };
const sampleText = "这是一份自编验证资料。\n样品验证仍需完成长循环测试，尚未取得客户量产定点。\n案例企业有小试经验，暂无持续量产验证记录。";
test("one live instance per data directory", t => {
  const { config } = fixture(t);
  const release = acquireInstance(config.dataDir);
  assert.throws(() => acquireInstance(config.dataDir), { code: "INSTANCE_ACTIVE" });
  release();
  acquireInstance(config.dataDir)();
});
function report(evidenceId, value = "样品尚未完成验证") {
  return [{ sectionId: "summary", heading: "摘要", gaps: [], paragraphs: [{ id: "p1", text: value, kind: "fact", evidenceIds: [evidenceId], review: "unreviewed" }] }];
}
async function settled(store, runId) {
  for (let i = 0; i < 100; i++) {
    const run = store.get("runs", runId);
    if (!["running", "queued"].includes(run.status)) return run;
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  throw new Error("Run did not finish");
}
test("SQLite persistence, optimistic project revision, archive and restore", t => {
  const { store, config } = fixture(t);
  const p = createProject(store, input);
  const updated = updateProject(store, p.id, { revision: 1, title: "更新后的课题" });
  assert.equal(updated.revision, 2);
  assert.throws(() => updateProject(store, p.id, { revision: 1, title: "过期写入" }), { code: "REVISION_CONFLICT" });
  const second = openStore(config.dataDir);
  assert.equal(second.get("projects", p.id).title, "更新后的课题"); second.close();
  const archived = updateProject(store, p.id, { revision: 2, archivedAt: true });
  assert.ok(archived.archivedAt);
  assert.equal(updateProject(store, p.id, { revision: 3, archivedAt: null }).archivedAt, null);
});
test("draft conflicts preserve server data; modifications invalidate previous review", t => {
  const { store, config } = fixture(t);
  const p = createProject(store, input);
  addTextSource(store, config, p.id, { text: sampleText });
  const e = store.list("evidence", p.id)[0];
  const d = saveDraft(store, p.id, { revision: 1, content: report(e.id) });
  d.content[0].paragraphs[0].review = "supported";
  const reviewed = saveDraft(store, p.id, { revision: 2, content: d.content });
  assert.equal(reviewed.content[0].paragraphs[0].review, "supported");
  assert.throws(() => saveDraft(store, p.id, { revision: 1, content: [] }), { code: "REVISION_CONFLICT" });
  reviewed.content[0].paragraphs[0].text = "用户修改后的判断";
  const changed = saveDraft(store, p.id, { revision: 3, content: reviewed.content });
  assert.equal(changed.content[0].paragraphs[0].review, "unreviewed");
});
test("cross-project citations and unknown IDs rejected; revisions immutable", t => {
  const { store, config } = fixture(t);
  const a = createProject(store, input), b = createProject(store, input);
  addTextSource(store, config, a.id, { text: sampleText });
  const e = store.list("evidence", a.id)[0];
  assert.throws(() => saveDraft(store, b.id, { revision: 1, content: report(e.id) }), { code: "INVALID_CITATION" });
  assert.throws(() => saveDraft(store, a.id, { revision: 1, content: report("missing") }), { code: "INVALID_CITATION" });
  const d = saveDraft(store, a.id, { revision: 1, content: report(e.id) });
  const version = snapshot(store, a.id, d.revision);
  saveDraft(store, a.id, { revision: 3, content: report(e.id, "新内容") });
  assert.equal(store.get("versions", version.id).content[0].paragraphs[0].text, "样品尚未完成验证");
});
test("Chinese evidence offsets refer to original text and stable content hash", t => {
  const { store, config } = fixture(t);
  const p = createProject(store, input);
  const body = `${sampleText}\n`.repeat(40);
  addTextSource(store, config, p.id, { text: body });
  const evidence = store.list("evidence", p.id);
  assert.ok(evidence.length > 1);
  for (const e of evidence) assert.equal(body.trim().slice(e.locator.start, e.locator.end), e.quote);
});
test("source extraction removes scripts and includes relevant body", () => {
  const html = `<html><head><title>技术公告</title></head><body><nav>导航链接</nav><article><h1>验证进展</h1>${Array.from({ length: 6 }, () => `<p>${sampleText}</p>`).join("")}<script>alert('hidden')</script></article></body></html>`;
  const article = extractHtml(html, "https://example.org/research");
  assert.ok(article.text.includes("长循环测试"));
  assert.ok(!article.text.includes("alert("));
});
test("RSS link elements parsed as XML, malformed source URLs rejected", async t => {
  const { store, config } = fixture(t);
  const p = createProject(store, input);
  const results = parseSearchFeed("<rss><channel><item><title>来源</title><link>https://example.org/report</link></item></channel></rss>");
  assert.equal(results[0].url, "https://example.org/report");
  await assert.rejects(addSource(store, config, p.id, { url: "bad-url" }), { code: "VALIDATION_ERROR" });
});
test("public address filter covers IPv4/IPv6 loopback, mapped and private ranges", async () => {
  for (const address of ["127.0.0.1", "10.1.1.1", "172.16.0.1", "192.168.1.1", "169.254.169.254", "::1", "::ffff:127.0.0.1", "fc00::1", "fe80::1", "0.0.0.0"]) assert.equal(isPublicAddress(address), false, address);
  assert.equal(isPublicAddress("8.8.8.8"), true);
  await assert.rejects(safeFetch("http://127.0.0.1/test"), { code: "SOURCE_BLOCKED" });
  await assert.rejects(safeFetch("file:///etc/passwd"), { code: "SOURCE_BLOCKED" });
});
test("model output schema and citation whitelist enforced; unsupported numbers flagged", () => {
  const evidence = [{ id: "e1", quote: sampleText }];
  assert.throws(() => checkOutput({ paragraphs: [{ text: "事实", kind: "fact", evidenceIds: ["bogus"] }], gaps: [] }, evidence), { code: "INVALID_CITATION" });
  assert.throws(() => checkOutput({ paragraphs: "not-array" }, evidence), { code: "MODEL_OUTPUT_INVALID" });
  const out = checkOutput({ paragraphs: [{ text: "市场规模达到 100 亿元", kind: "fact", evidenceIds: ["e1"] }], gaps: [] }, evidence);
  assert.ok(out.gaps.some(g => g.includes("100")));
  assert.equal(out.paragraphs[0].review, "unreviewed");
});
test("model failures expose errors, no template fallback", async () => {
  const config = { apiKey: "fake-test-key", model: "test" };
  const signal = new AbortController().signal;
  await assert.rejects(generateSection(config, {}, signal, async () => ({ ok: false, status: 401, json: async () => ({ error: {} }) })), { code: "MODEL_UPSTREAM_ERROR" });
  await assert.rejects(generateSection(config, {}, signal, async () => ({ ok: true, json: async () => ({ status: "incomplete" }) })), { code: "MODEL_OUTPUT_INVALID" });
  await assert.rejects(generateSection(config, {}, signal, async () => ({ ok: true, json: async () => ({ output: [{ content: [{ type: "refusal" }] }] }) })), { code: "MODEL_REFUSED" });
});
test("model adapter supports configurable OpenAI-compatible chat endpoint", async () => {
  const evidence = [{ id: "e1", quote: sampleText }];
  let called;
  const result = await generateSection(
    { apiKey: "test-key", apiBaseUrl: "https://aijump.cc/v1", endpoint: "chat", model: "demo-model" },
    { evidence },
    new AbortController().signal,
    async (url, options) => {
      called = { url, body: JSON.parse(options.body), auth: options.headers.authorization };
      return {
        ok: true,
        json: async () => ({
          id: "chatcmpl-test",
          choices: [{ message: { content: JSON.stringify({ paragraphs: [{ text: "建议继续核验", kind: "analysis", evidenceIds: ["e1"] }], gaps: [] }) } }],
          usage: { total_tokens: 42 },
        }),
      };
    }
  );
  assert.equal(called.url, "https://aijump.cc/v1/chat/completions");
  assert.equal(called.body.response_format.type, "json_schema");
  assert.equal(called.body.model, "demo-model");
  assert.equal(called.auth, "Bearer test-key");
  assert.equal(result.output.paragraphs[0].text, "建议继续核验");
});
test("workflow generates candidates, preserves editable report, reuses idempotent request", async t => {
  const { store, config } = fixture(t);
  config.apiKey = "fake-test-key";
  const p = createProject(store, input);
  addTextSource(store, config, p.id, { text: sampleText });
  const e = store.list("evidence", p.id)[0];
  saveDraft(store, p.id, { revision: 1, content: report(e.id, "用户旧报告") });
  let calls = 0;
  const workflow = createWorkflow(store, config, { generate: async (_config, data) => { calls++; return { output: checkOutput({ paragraphs: [{ text: "新生成报告", kind: "analysis", evidenceIds: [data.evidence[0].id] }], gaps: [] }, data.evidence), usage: { total_tokens: 100 } }; } });
  const run = workflow.start(p.id, { clientRequestId: "test-request", confirmedPlan: true });
  const done = await settled(store, run.id);
  assert.equal(done.status, "succeeded");
  assert.equal(calls, 2);
  assert.equal(store.get("drafts", p.id).content[0].paragraphs[0].text, "用户旧报告");
  assert.equal(workflow.start(p.id, { clientRequestId: "test-request", confirmedPlan: true }).id, run.id);
  assert.ok(done.versionId);
});
test("partial run resumes only failed chapters; completed steps are retained", async t => {
  const { store, config } = fixture(t); config.apiKey = "fake";
  const p = createProject(store, input);
  addTextSource(store, config, p.id, { text: sampleText });
  let calls = 0;
  const workflow = createWorkflow(store, config, { generate: async (_config, data) => {
    calls++; if (calls === 2) throw new Error("temporary model error");
    return { output: checkOutput({ paragraphs: [{ text: "验证结果", kind: "analysis", evidenceIds: [data.evidence[0].id] }], gaps: [] }, data.evidence) };
  } });
  const run = workflow.start(p.id, { clientRequestId: "partial", confirmedPlan: true });
  assert.equal((await settled(store, run.id)).status, "partial");
  workflow.resume(run.id);
  assert.equal((await settled(store, run.id)).status, "succeeded");
  assert.equal(calls, 3);
});
test("temporary upstream errors retry within budget", async t => {
  const { store, config } = fixture(t); config.apiKey = "fake";
  const p = createProject(store, { ...input, enabledSections: ["summary"] });
  addTextSource(store, config, p.id, { text: sampleText });
  let calls = 0;
  const workflow = createWorkflow(store, config, { generate: async (_config, data) => {
    calls++;
    if (calls === 1) { const error = new Error("rate limited"); error.retryable = true; error.retryAfterMs = 1; throw error; }
    return { output: checkOutput({ paragraphs: [{ text: "验证结果", kind: "analysis", evidenceIds: [data.evidence[0].id] }], gaps: [] }, data.evidence) };
  } });
  const run = workflow.start(p.id, { clientRequestId: "retry", confirmedPlan: true });
  assert.equal((await settled(store, run.id)).status, "succeeded"); assert.equal(calls, 2);
});
test("invalid model output gets one repair call, authentication errors do not retry", async t => {
  const { store, config } = fixture(t); config.apiKey = "fake";
  const p = createProject(store, { ...input, enabledSections: ["summary"] });
  addTextSource(store, config, p.id, { text: sampleText });
  let calls = 0;
  const workflow = createWorkflow(store, config, { generate: async (_config, data) => {
    calls++;
    if (calls === 1) { const error = new Error("bad schema"); error.code = "MODEL_OUTPUT_INVALID"; throw error; }
    assert.ok(data.correction);
    return { output: checkOutput({ paragraphs: [{ text: "验证结果", kind: "analysis", evidenceIds: [data.evidence[0].id] }], gaps: [] }, data.evidence) };
  } });
  const run = workflow.start(p.id, { clientRequestId: "repair", confirmedPlan: true });
  assert.equal((await settled(store, run.id)).status, "succeeded"); assert.equal(calls, 2);
  let authCalls = 0;
  const auth = createWorkflow(store, config, { generate: async () => { authCalls++; const error = new Error("401"); error.retryable = false; throw error; } });
  const failed = auth.start(p.id, { clientRequestId: "auth", confirmedPlan: true });
  assert.equal((await settled(store, failed.id)).status, "failed"); assert.equal(authCalls, 1);
});
test("cancellation retains completed collection and prevents further model calls", async t => {
  const { store, config } = fixture(t); config.apiKey = "fake";
  const p = createProject(store, input); addTextSource(store, config, p.id, { text: sampleText });
  const workflow = createWorkflow(store, config, { generate: (_config, _input, signal) => new Promise((resolve, reject) => { signal.addEventListener("abort", () => reject(signal.reason), { once: true }); }) });
  const run = workflow.start(p.id, { clientRequestId: "cancel", confirmedPlan: true });
  assert.throws(() => workflow.start(p.id, { clientRequestId: "duplicate-active", confirmedPlan: true }), { code: "RUN_ACTIVE" });
  workflow.cancel(run.id);
  const done = await settled(store, run.id);
  assert.equal(done.status, "cancelled");
  assert.equal(done.steps[0].status, "succeeded");
  assert.equal(done.calls[0].status, "unknown");
});
test("startup marks incomplete runs interrupted without automatic model calls", t => {
  const { store, config } = fixture(t);
  const p = createProject(store, input);
  store.put("runs", { id: "interrupted", projectId: p.id, requestId: "test", status: "running", steps: [{ status: "running" }], calls: [{ status: "running" }] });
  const reopened = openStore(config.dataDir);
  const run = reopened.get("runs", "interrupted");
  assert.equal(run.status, "interrupted"); assert.equal(run.calls[0].status, "unknown"); reopened.close();
});
test("no sources fails honestly; missing key prevents any run creation", async t => {
  const { store, config } = fixture(t);
  const p = createProject(store, input);
  let workflow = createWorkflow(store, config);
  assert.throws(() => workflow.start(p.id, { confirmedPlan: true, clientRequestId: "no-key" }), { code: "MODEL_NOT_CONFIGURED" });
  assert.equal(store.list("runs").length, 0);
  config.apiKey = "fake";
  workflow = createWorkflow(store, config, { generate: () => { throw new Error("must not call"); } });
  const run = workflow.start(p.id, { confirmedPlan: true, clientRequestId: "no-sources" });
  const done = await settled(store, run.id);
  assert.equal(done.status, "failed"); assert.equal(done.calls.length, 0);
});
test("demo export includes explicit identity, source dates and quote", t => {
  const { store, config } = fixture(t);
  const project = seedDemo(store, config);
  assert.equal(seedDemo(store, config).id, project.id);
  const version = store.list("versions", project.id)[0];
  const exported = markdown(project, version, store.list("evidence", project.id), store.list("sources", project.id));
  assert.match(exported, /演示数据/); assert.match(exported, /采集时间/); assert.match(exported, /待核验/);
  assert.match(exported, /长循环测试/); assert.ok(!exported.includes(config.dataDir));
});
test("HTTP endpoints: malformed JSON, cross-origin, static boundary, CRUD and SSE replay", async t => {
  const { store, config } = fixture(t);
  const workflow = createWorkflow(store, config);
  const server = createHttpServer({ store, config, workflow, root: resolve(".") });
  await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  const url = `http://127.0.0.1:${server.address().port}`;
  const request = (path, options = {}) => fetch(`${url}${path}`, options);
  for (const path of ["/.env", "/data/workbench.sqlite", "/server.mjs", "/server/db.mjs", "/package.json", "/output/imagegen/kitten.png"]) {
    assert.equal((await request(path)).status, 404, path);
  }
  assert.equal((await request("/")).status, 200);
  assert.equal((await request("/ui/app.js")).status, 200);
  assert.equal((await request("/api/projects", { method: "POST", headers: { "content-type": "application/json" }, body: "{" })).status, 400);
  assert.equal((await request("/api/projects", { method: "POST", headers: { "content-type": "application/json", origin: "https://evil.example" }, body: JSON.stringify(input) })).status, 403);
  const response = await request("/api/projects", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input) });
  assert.equal(response.status, 201);
  const { data: p } = await response.json();
  assert.equal((await (await request(`/api/projects/${p.id}`)).json()).data.id, p.id);
  const run = store.put("runs", { id: "test-event-run", projectId: p.id, requestId: "event", status: "failed", steps: [], calls: [] });
  const seq = store.event(run.id, "run.failed", { status: "failed" });
  assert.equal(store.events(run.id, Number(seq) - 1).length, 1);
  assert.equal(store.events(run.id, Number(seq)).length, 0);
  const controller = new AbortController();
  const sse = await request(`/api/runs/${run.id}/events`, { signal: controller.signal });
  const chunk = await sse.body.getReader().read();
  assert.match(new TextDecoder().decode(chunk.value), /run.failed/); controller.abort();
});
