export const sections = [
  ["summary", "研究摘要"], ["technology", "技术路线"], ["market", "市场与需求"],
  ["competition", "竞争格局"], ["strategy", "企业匹配与建议"], ["risks", "风险与验证"]
];
export const reviews = ["unreviewed", "supported", "partial", "unsupported"];
export class AppError extends Error {
  constructor(code, message, status = 400) { super(message); this.code = code; this.status = status; }
}
export function requireValue(condition, message, code = "VALIDATION_ERROR", status = 400) {
  if (!condition) throw new AppError(code, message, status);
}
export function text(value, label, max = 5000, required = true) {
  requireValue(typeof value === "string" && value.length <= max && (!required || value.trim()), `${label}不能为空或超过 ${max} 字符`);
  return value.trim();
}
export function projectInput(input) {
  requireValue(input.enabledSections === undefined || Array.isArray(input.enabledSections), "报告章节必须为数组");
  return {
    title: text(input.title, "课题名称", 200),
    material: text(input.material, "材料", 100),
    question: text(input.question, "研究问题", 5000),
    scope: text(input.scope ?? "", "范围", 2000, false),
    profile: text(input.profile ?? "", "企业背景", 5000, false),
    enabledSections: [...new Set(input.enabledSections ?? sections.map(([id]) => id))],
    mode: input.mode === "demo" ? "demo" : "real"
  };
}
export function validSections(ids) {
  requireValue(Array.isArray(ids) && ids.length > 0 && ids.length <= sections.length && ids.every(id => sections.some(([key]) => id === key)), "请选择有效的报告章节");
}
export const paragraphSchema = {
  type: "object", additionalProperties: false, required: ["text", "kind", "evidenceIds"],
  properties: {
    text: { type: "string" }, kind: { type: "string", enum: ["fact", "analysis", "hypothesis"] },
    evidenceIds: { type: "array", items: { type: "string" } }
  }
};
export const modelSchema = {
  type: "object", additionalProperties: false, required: ["paragraphs", "gaps"],
  properties: {
    paragraphs: { type: "array", items: paragraphSchema },
    gaps: { type: "array", items: { type: "string" } }
  }
};
