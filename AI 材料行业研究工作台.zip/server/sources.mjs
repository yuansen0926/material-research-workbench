import { request as httpsRequest } from "node:https";
import { request as httpRequest } from "node:http";
import { lookup } from "node:dns/promises";
import { createHash } from "node:crypto";
import { writeFileSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import ipaddr from "ipaddr.js";
import { parseHTML, DOMParser } from "linkedom";
import { Readability } from "@mozilla/readability";
import { AppError, requireValue, text } from "../shared/contracts.mjs";
import { id, now } from "./db.mjs";

export const hash = value => createHash("sha256").update(value).digest("hex");
export function isPublicAddress(address) {
  try { return ipaddr.process(address).range() === "unicast"; } catch { return false; }
}
export async function safeFetch(target, { signal, maxBytes = 5 * 1024 * 1024, redirects = 0 } = {}) {
  let url;
  try { url = new URL(target); } catch { throw new AppError("SOURCE_BLOCKED", "请输入有效网址"); }
  requireValue(["http:", "https:"].includes(url.protocol) && !url.username && !url.password && (!url.port || ["80", "443"].includes(url.port)), "仅支持公开 HTTP(S) 网页的标准端口", "SOURCE_BLOCKED");
  requireValue(redirects <= 4, "网页重定向过多", "SOURCE_BLOCKED");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  const addresses = await lookup(host, { all: true });
  requireValue(addresses.length && addresses.every(a => isPublicAddress(a.address)), "不允许抓取本机、内网或保留地址", "SOURCE_BLOCKED");
  const pinned = addresses[0];
  const result = await new Promise((resolve, reject) => {
    // Pin the checked DNS result to the connection, preventing DNS rebinding.
    const req = (url.protocol === "https:" ? httpsRequest : httpRequest)(url, {
      signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(15000)]) : AbortSignal.timeout(15000),
      headers: { "user-agent": "MaterialResearchWorkbench/0.1", "accept-encoding": "identity" },
      lookup: (_hostname, options, callback) => options.all ? callback(null, [pinned]) : callback(null, pinned.address, pinned.family)
    }, res => {
      const chunks = []; let size = 0;
      res.on("error", reject);
      res.on("data", chunk => {
        size += chunk.length;
        if (size > maxBytes) { req.destroy(new AppError("SOURCE_TOO_LARGE", "网页超过 5 MiB 限制", 422)); return; }
        chunks.push(chunk);
      });
      res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString("utf8"), url: url.href }));
    });
    req.on("error", reject); req.end();
  });
  if (result.status >= 300 && result.status < 400 && result.headers.location) return safeFetch(new URL(result.headers.location, url).href, { signal, maxBytes, redirects: redirects + 1 });
  requireValue(result.status >= 200 && result.status < 300, `来源返回 HTTP ${result.status}`, "SOURCE_FETCH_FAILED", 502);
  return result;
}
export function extractHtml(html, url) {
  const { document } = parseHTML(html);
  const title = document.querySelector("title")?.textContent?.trim() || new URL(url).hostname;
  const publishedAt = document.querySelector('meta[property="article:published_time"]')?.getAttribute("content") || null;
  const article = new Readability(document, { charThreshold: 100 }).parse();
  requireValue(article?.textContent?.trim().length >= 80, "未能提取足够正文，请粘贴原文；不支持扫描 PDF 或登录页面", "SOURCE_UNSUPPORTED", 422);
  return { title: article.title || title, text: article.textContent.trim(), publishedAt };
}
export function chunkEvidence(source, body) {
  const chunks = [];
  // Offsets are produced from stored text, never supplied by a model.
  for (let start = 0; start < body.length && chunks.length < 400;) {
    let end = Math.min(start + 1000, body.length);
    if (end < body.length) {
      const newline = body.lastIndexOf("\n", end);
      if (newline > start + 200) end = newline + 1;
    }
    const quote = body.slice(start, end);
    if (quote.trim()) chunks.push({ id: id(), projectId: source.projectId, sourceId: source.id, quote, locator: { start, end, contentHash: source.contentHash, kind: "text" }, createdAt: now() });
    start = end;
  }
  return chunks;
}
export function sourceBody(config, source) {
  return readFileSync(join(config.dataDir, "sources", `${source.id}.txt`), "utf8");
}
export function addTextSource(store, config, projectId, input) {
  store.get("projects", projectId);
  const body = text(input.text, "正文", 200000);
  requireValue(body.length >= 20, "原文至少需要 20 字符");
  const source = { id: id(), projectId, title: text(input.title || "粘贴的研究资料", "标题", 500), url: input.url || null, publishedAt: input.publishedAt || null, fetchedAt: now(), status: "ready", contentHash: hash(body), error: null };
  mkdirSync(join(config.dataDir, "sources"), { recursive: true });
  writeFileSync(join(config.dataDir, "sources", `${source.id}.txt`), body, "utf8");
  return store.transaction(() => {
    store.put("sources", source);
    for (const evidence of chunkEvidence(source, body)) store.put("evidence", evidence);
    return source;
  });
}
export async function addSource(store, config, projectId, input, signal) {
  if (input.text) return addTextSource(store, config, projectId, input);
  const url = text(input.url, "网址", 4000);
  let parsed;
  try { parsed = new URL(url); } catch { throw new AppError("VALIDATION_ERROR", "请输入完整的 HTTP(S) 网页链接"); }
  requireValue(["http:", "https:"].includes(parsed.protocol), "仅支持 HTTP(S) 网页链接");
  try {
    const response = await safeFetch(url, { signal });
    requireValue(/text\/html|text\/plain/.test(response.headers["content-type"] || ""), "仅支持 HTML 或纯文本；PDF 请先提取文字", "SOURCE_UNSUPPORTED", 422);
    const article = /text\/plain/.test(response.headers["content-type"]) ? { title: new URL(url).hostname, text: response.text } : extractHtml(response.text, response.url);
    return addTextSource(store, config, projectId, { ...article, url: response.url });
  } catch (error) {
    const source = store.put("sources", { id: id(), projectId, url, title: url, status: "failed", fetchedAt: now(), publishedAt: null, error: error.message });
    return source;
  }
}
export async function searchWeb(query, signal) {
  const response = await safeFetch(`https://www.bing.com/search?format=rss&q=${encodeURIComponent(query)}`, { signal });
  return parseSearchFeed(response.text);
}
export function parseSearchFeed(xml) {
  const document = new DOMParser().parseFromString(xml, "text/xml");
  return [...document.querySelectorAll("item")].slice(0, 4).map(item => ({
    title: item.querySelector("title")?.textContent || "",
    url: item.querySelector("link")?.textContent || ""
  })).filter(item => /^https?:\/\//.test(item.url));
}
