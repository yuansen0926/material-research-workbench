import { resolve } from "node:path";
import { requireValue } from "../shared/contracts.mjs";
export function getConfig(env = process.env) {
  const config = {
    port: Number(env.PORT || 4173), dataDir: resolve(env.DATA_DIR || "./data"),
    apiKey: env.OPENAI_API_KEY || "", model: env.OPENAI_MODEL || "gpt-4.1-mini",
    apiBaseUrl: (env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, ""),
    endpoint: env.OPENAI_ENDPOINT || "responses",
    maxCalls: Number(env.MAX_MODEL_CALLS || 16), maxMinutes: Number(env.MAX_RUN_MINUTES || 10)
  };
  requireValue(Number.isInteger(config.port) && config.port >= 0 && config.port <= 65535, "PORT 无效");
  requireValue(/^https?:\/\/[^/]+/.test(config.apiBaseUrl), "OPENAI_BASE_URL 必须是 http(s) 地址");
  requireValue(["responses", "chat"].includes(config.endpoint), "OPENAI_ENDPOINT 只能是 responses 或 chat");
  requireValue(Number.isInteger(config.maxCalls) && config.maxCalls > 0 && config.maxCalls <= 100, "MAX_MODEL_CALLS 必须为 1—100");
  requireValue(Number.isFinite(config.maxMinutes) && config.maxMinutes > 0 && config.maxMinutes <= 60, "MAX_RUN_MINUTES 必须为 1—60");
  return config;
}
