import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { requireValue } from "../shared/contracts.mjs";
export const id = () => randomUUID();
export const now = () => new Date().toISOString();

export function openStore(directory) {
  mkdirSync(directory, { recursive: true });
  const db = new DatabaseSync(join(directory, "workbench.sqlite"));
  db.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
  const version = db.prepare("PRAGMA user_version").get().user_version;
  requireValue(version <= 1, "数据库版本高于此应用支持版本");
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS drafts(project_id TEXT PRIMARY KEY REFERENCES projects(id), data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS versions(id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS evidence(id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), request_id TEXT NOT NULL, data TEXT NOT NULL, UNIQUE(project_id,request_id));
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES runs(id), type TEXT NOT NULL, data TEXT NOT NULL);
    PRAGMA user_version=1;
  `);
  const tables = new Set(["projects", "drafts", "versions", "sources", "evidence", "runs"]);
  function table(name) { requireValue(tables.has(name), "未知数据表"); return name; }
  function transaction(fn) {
    db.exec("BEGIN IMMEDIATE");
    try { const result = fn(); db.exec("COMMIT"); return result; }
    catch (error) { db.exec("ROLLBACK"); throw error; }
  }
  function get(name, key) {
    const row = db.prepare(`SELECT data FROM ${table(name)} WHERE ${name === "drafts" ? "project_id" : "id"}=?`).get(key);
    requireValue(row, "记录不存在", "NOT_FOUND", 404);
    return JSON.parse(row.data);
  }
  function list(name, projectId) {
    return db.prepare(`SELECT data FROM ${table(name)}${projectId ? " WHERE project_id=?" : ""}`)
      .all(...(projectId ? [projectId] : [])).map(row => JSON.parse(row.data));
  }
  function put(name, value) {
    table(name);
    if (name === "projects") db.prepare("INSERT INTO projects VALUES (?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data").run(value.id, JSON.stringify(value));
    else if (name === "drafts") db.prepare("INSERT INTO drafts VALUES (?,?) ON CONFLICT(project_id) DO UPDATE SET data=excluded.data").run(value.projectId, JSON.stringify(value));
    else if (name === "runs") db.prepare("INSERT INTO runs VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data").run(value.id, value.projectId, value.requestId, JSON.stringify(value));
    else db.prepare(`INSERT INTO ${name} VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`).run(value.id, value.projectId, JSON.stringify(value));
    return value;
  }
  function event(runId, type, data) {
    return db.prepare("INSERT INTO events(run_id,type,data) VALUES (?,?,?)").run(runId, type, JSON.stringify({ ...data, at: now() })).lastInsertRowid;
  }
  function events(runId, after = 0) {
    return db.prepare("SELECT * FROM events WHERE run_id=? AND id>? ORDER BY id LIMIT 100").all(runId, after).map(row => ({ ...row, data: JSON.parse(row.data) }));
  }
  for (const run of list("runs")) {
    if (run.status === "running" || run.status === "queued") {
      run.status = "interrupted";
      run.steps.forEach(step => { if (step.status === "running") step.status = "interrupted"; });
      run.calls.forEach(call => { if (call.status === "running") call.status = "unknown"; });
      put("runs", run);
    }
  }
  return { get, list, put, transaction, event, events, close: () => db.close() };
}
