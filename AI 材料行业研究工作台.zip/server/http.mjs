import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
import { randomUUID } from "node:crypto";
import { AppError, requireValue, sections } from "../shared/contracts.mjs";
import { createProject, updateProject, saveDraft, snapshot, validateContent } from "./projects.mjs";
import { id, now } from "./db.mjs";
import { addSource, sourceBody } from "./sources.mjs";
import { markdown } from "./exports.mjs";
import { seedDemo } from "../fixtures/demo.mjs";

async function body(req) {
  requireValue((req.headers["content-type"] || "").split(";")[0] === "application/json", "请求必须为 application/json", "VALIDATION_ERROR", 415);
  const parts = []; let length = 0;
  for await (const part of req) {
    length += part.length; requireValue(length <= 1048576, "请求超过 1 MiB 限制", "BODY_TOO_LARGE", 413); parts.push(part);
  }
  try {
    const value = JSON.parse(Buffer.concat(parts).toString() || "{}");
    requireValue(value && typeof value === "object" && !Array.isArray(value), "请求必须为 JSON 对象");
    return value;
  } catch (error) { throw error instanceof AppError ? error : new AppError("VALIDATION_ERROR", "JSON 格式错误"); }
}
function json(res, data, status = 200) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }); res.end(JSON.stringify({ data }));
}
function owned(store, table, key, projectId) {
  const value = store.get(table, key);
  requireValue(value.projectId === projectId, "记录不存在", "NOT_FOUND", 404);
  return value;
}
export function createHttpServer({ store, config, workflow, root }) {
  const server = createServer(async (req, res) => {
    try {
      const host = req.headers.host || "";
      requireValue(/^(127\.0\.0\.1|localhost):\d+$/.test(host), "不允许的 Host", "FORBIDDEN", 403);
      if (!["GET", "HEAD"].includes(req.method)) {
        requireValue(!req.headers.origin || req.headers.origin === `http://${host}`, "不允许跨域修改数据", "FORBIDDEN", 403);
        requireValue(req.headers["sec-fetch-site"] !== "cross-site", "不允许跨站请求", "FORBIDDEN", 403);
      }
      res.setHeader("x-content-type-options", "nosniff");
      res.setHeader("referrer-policy", "no-referrer");
      res.setHeader("content-security-policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
      const url = new URL(req.url, `http://${host}`);
      const path = url.pathname;
      const method = req.method;
      if (path === "/api/health" && method === "GET") return json(res, { ok: true, version: "0.1.0", schema: 1 });
      if (path === "/api/settings/status" && method === "GET") return json(res, { configured: Boolean(config.apiKey), model: config.model, apiBaseUrl: config.apiBaseUrl, endpoint: config.endpoint, dataDirectory: config.dataDir, maxCalls: config.maxCalls, maxMinutes: config.maxMinutes });
      if (path === "/api/settings/check" && method === "POST") {
        await body(req); requireValue(config.apiKey, "未配置 OPENAI_API_KEY", "MODEL_NOT_CONFIGURED");
        const response = await fetch(`${config.apiBaseUrl}/models`, { headers: { authorization: `Bearer ${config.apiKey}` }, signal: AbortSignal.timeout(15000) });
        requireValue(response.ok, `模型连接检查返回 HTTP ${response.status}`, "MODEL_UPSTREAM_ERROR", 502);
        return json(res, { connected: true, model: config.model });
      }
      if (path === "/api/demo" && method === "POST") { await body(req); return json(res, seedDemo(store, config), 201); }
      if (path === "/api/projects") {
        if (method === "POST") return json(res, createProject(store, await body(req)), 201);
        if (method === "GET") {
          const q = (url.searchParams.get("q") || "").toLowerCase();
          const archived = url.searchParams.get("archived") === "true";
          const limit = Math.min(50, Math.max(1, Number(url.searchParams.get("limit")) || 50));
          const offset = Math.max(0, Number(url.searchParams.get("cursor")) || 0);
          const projects = store.list("projects").filter(p => Boolean(p.archivedAt) === archived && `${p.title} ${p.material} ${p.question}`.toLowerCase().includes(q)).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
          return json(res, { items: projects.slice(offset, offset + limit), nextCursor: offset + limit < projects.length ? String(offset + limit) : null });
        }
      }
      const match = path.match(/^\/api\/projects\/([^/]+)(?:\/(.*))?$/);
      if (match) {
        const projectId = match[1], tail = match[2] || "";
        const project = store.get("projects", projectId);
        if (!tail && method === "GET") return json(res, project);
        if (!tail && method === "PATCH") return json(res, updateProject(store, projectId, await body(req)));
        if (tail === "draft" && method === "GET") return json(res, store.get("drafts", projectId));
        if (tail === "draft" && method === "PUT") return json(res, saveDraft(store, projectId, await body(req)));
        if (tail === "versions") {
          if (method === "POST") {
            const input = await body(req);
            if (input.content) {
              validateContent(store, projectId, input.content);
              const content = structuredClone(input.content);
              content.flatMap(s => s.paragraphs).forEach(p => { p.review = "unreviewed"; });
              return json(res, store.put("versions", { id: id(), projectId, parentId: null, origin: project.mode === "demo" ? "demo" : "manual", content, createdAt: now(), note: "冲突编辑另存" }), 201);
            }
            return json(res, snapshot(store, projectId, input.draftRevision), 201);
          }
          if (method === "GET") return json(res, store.list("versions", projectId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(({ content, ...v }) => ({ ...v, sectionCount: content.length })));
        }
        if (tail.startsWith("versions/") && method === "GET") return json(res, owned(store, "versions", tail.split("/")[1], projectId));
        if (tail === "sources") {
          if (method === "GET") return json(res, store.list("sources", projectId));
          if (method === "POST") return json(res, await addSource(store, config, projectId, await body(req)), 201);
        }
        if (tail.match(/^sources\/[^/]+\/retry$/) && method === "POST") {
          await body(req); const source = owned(store, "sources", tail.split("/")[1], projectId);
          requireValue(source.status === "failed" && source.url, "此来源无需重试");
          return json(res, await addSource(store, config, projectId, { url: source.url }), 201);
        }
        if (tail.startsWith("sources/") && method === "GET") {
          const source = owned(store, "sources", tail.split("/")[1], projectId);
          return json(res, { ...source, text: source.status === "ready" ? sourceBody(config, source) : null });
        }
        if (tail.startsWith("evidence/") && method === "GET") {
          const evidence = owned(store, "evidence", tail.split("/")[1], projectId);
          return json(res, { ...evidence, source: owned(store, "sources", evidence.sourceId, projectId) });
        }
        if (tail === "plan" && method === "POST") {
          await body(req);
          return json(res, { query: `${project.material} ${project.question}`, sections: sections.filter(([key]) => project.enabledSections.includes(key)), availableSources: store.list("sources", projectId).filter(s => s.status === "ready").length });
        }
        if (tail === "runs") {
          if (method === "GET") return json(res, store.list("runs", projectId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
          if (method === "POST") return json(res, workflow.start(projectId, await body(req)), 202);
        }
        if (tail === "export" && method === "GET") {
          const version = owned(store, "versions", url.searchParams.get("versionId"), projectId);
          requireValue(url.searchParams.get("format") === "md", "目前支持 Markdown 格式");
          res.writeHead(200, { "content-type": "text/markdown; charset=utf-8", "content-disposition": `attachment; filename="research.md"; filename*=UTF-8''${encodeURIComponent(project.title)}.md`, "cache-control": "no-store" });
          return res.end(markdown(project, version, store.list("evidence", projectId), store.list("sources", projectId)));
        }
      }
      const runMatch = path.match(/^\/api\/runs\/([^/]+)(?:\/(events|resume|cancel))?$/);
      if (runMatch) {
        const run = store.get("runs", runMatch[1]);
        if (!runMatch[2] && method === "GET") return json(res, run);
        if (runMatch[2] === "cancel" && method === "POST") { await body(req); return json(res, workflow.cancel(run.id), 202); }
        if (runMatch[2] === "resume" && method === "POST") { await body(req); return json(res, workflow.resume(run.id), 202); }
        if (runMatch[2] === "events" && method === "GET") {
          let after = Math.max(0, Number(req.headers["last-event-id"] || url.searchParams.get("after")) || 0);
          res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache", connection: "keep-alive" });
          const send = () => {
            for (const event of store.events(run.id, after)) {
              res.write(`id: ${event.id}\nevent: update\ndata: ${JSON.stringify({ type: event.type, ...event.data })}\n\n`); after = event.id;
            }
          };
          send(); const timer = setInterval(send, 800);
          const heartbeat = setInterval(() => res.write(": heartbeat\n\n"), 15000);
          res.on("close", () => { clearInterval(timer); clearInterval(heartbeat); });
          return;
        }
      }
      if (method === "GET" || method === "HEAD") {
        const relative = path === "/" ? "workbench.html" : path.slice(1);
        let file;
        if (relative === "workbench.html" || /^ui\/[a-z0-9/-]+\.(js|css)$/.test(relative) || relative === "shared/contracts.mjs") file = resolve(root, relative);
        else if (/^icons\/[a-z0-9-]+\.svg$/.test(relative)) file = resolve(root, "node_modules/lucide-static/icons", relative.slice(6));
        requireValue(file && file.startsWith(resolve(root) + sep), "页面不存在", "NOT_FOUND", 404);
        let data; try { data = await readFile(file); } catch { throw new AppError("NOT_FOUND", "文件不存在", 404); }
        const type = { ".html": "text/html", ".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml" }[extname(file)];
        res.writeHead(200, { "content-type": `${type}; charset=utf-8`, "cache-control": "no-cache" });
        return res.end(method === "HEAD" ? undefined : data);
      }
      throw new AppError("NOT_FOUND", "接口不存在", 404);
    } catch (error) {
      if (res.headersSent) return res.end();
      const status = error.status || 500;
      res.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
      res.end(JSON.stringify({ error: { code: error.code || "INTERNAL_ERROR", message: status === 500 ? "服务处理失败，请重试并检查本地日志" : error.message, retryable: status >= 500 || status === 429, requestId: randomUUID() } }));
      if (status === 500) console.error(error.message);
    }
  });
  return server;
}
