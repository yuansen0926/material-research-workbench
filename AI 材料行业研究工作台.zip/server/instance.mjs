import { mkdirSync, openSync, writeFileSync, readFileSync, unlinkSync, closeSync } from "node:fs";
import { join } from "node:path";
import { AppError } from "../shared/contracts.mjs";

export function acquireInstance(directory) {
  mkdirSync(directory, { recursive: true });
  const path = join(directory, "workbench.lock");
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const handle = openSync(path, "wx");
      try { writeFileSync(handle, JSON.stringify({ pid: process.pid })); } finally { closeSync(handle); }
      return () => {
        try { if (JSON.parse(readFileSync(path, "utf8")).pid === process.pid) unlinkSync(path); } catch {}
      };
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      let owner;
      try { owner = JSON.parse(readFileSync(path, "utf8")).pid; } catch { throw new AppError("INSTANCE_ACTIVE", "数据目录已锁定，另一个工作台可能正在启动。"); }
      let alive = true;
      try { process.kill(owner, 0); } catch (error) { if (error.code === "ESRCH") alive = false; }
      if (alive) throw new AppError("INSTANCE_ACTIVE", `此数据目录的工作台已在运行（PID ${owner}）。请使用已打开的服务，或停止后再重启。`);
      try { unlinkSync(path); } catch (error) { if (error.code !== "ENOENT") throw error; }
    }
  }
  throw new AppError("INSTANCE_ACTIVE", "无法取得本地数据锁，请检查已有工作台进程。");
}
