export function markdown(project, version, evidence, sources) {
  const refs = new Map();
  const reviewNames = { unreviewed: "待核验", supported: "支持", partial: "部分支持", unsupported: "不支持" };
  const lines = [`# ${project.title}`, "", project.mode === "demo" ? "> 演示数据：自编案例，不可用于行业判断。" : "> AI 辅助研究初稿；请核验关键结论。", "", `版本日期：${version.createdAt}`, "", `研究问题：${project.question}`, ""];
  for (const section of version.content) {
    lines.push(`## ${section.heading}`, "");
    for (const p of section.paragraphs) {
      const numbers = p.evidenceIds.map(key => { if (!refs.has(key)) refs.set(key, refs.size + 1); return `[${refs.get(key)}]`; });
      lines.push(`${p.text} ${numbers.join("")}`, "", `*${p.kind} · ${reviewNames[p.review] || "待核验"}*`, "");
    }
    if (section.gaps.length) lines.push("待核验：", ...section.gaps.map(g => `- ${g}`), "");
  }
  lines.push("## 原文证据", "");
  for (const [key, number] of refs) {
    const e = evidence.find(item => item.id === key);
    const s = sources.find(item => item.id === e?.sourceId);
    lines.push(`### [${number}] ${s?.title || "来源缺失"}`, "", `来源：${s?.url || "用户提供文字"}；发布日期：${s?.publishedAt || "未知"}；采集时间：${s?.fetchedAt || "未知"}`, "", ...(e?.quote || "证据缺失").split("\n").map(line => `> ${line}`), "");
  }
  return lines.join("\n");
}
