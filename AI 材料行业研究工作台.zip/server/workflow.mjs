import { id, now } from "./db.mjs";
import { sections, requireValue } from "../shared/contracts.mjs";
import { addSource, hash, searchWeb, sourceBody } from "./sources.mjs";
import { generateSection } from "./model.mjs";
import { setTimeout as delay } from "node:timers/promises";

export function createWorkflow(store, config, dependencies = {}) {
  const generate = dependencies.generate || generateSection;
  const search = dependencies.search || searchWeb;
  let active = null;
  const emit = (run, type = "step.updated") => { store.put("runs", run); store.event(run.id, type, { status: run.status }); };
  function start(projectId, input) {
    const previous = store.list("runs", projectId).find(r => r.requestId === input.clientRequestId);
    if (previous) return previous;
    requireValue(!active, "已有研究正在执行", "RUN_ACTIVE", 409);
    requireValue(config.apiKey, "请先配置模型连接", "MODEL_NOT_CONFIGURED");
    const project = store.get("projects", projectId);
    requireValue(project.mode === "real", "演示案例不能调用真实研究；请新建正式项目");
    requireValue(input.confirmedPlan === true, "请确认研究计划");
    requireValue(typeof input.clientRequestId === "string" && input.clientRequestId.length <= 100, "缺少请求标识");
    requireValue(!input.sectionId || project.enabledSections.includes(input.sectionId), "章节不属于当前研究计划");
    const sourceIds = store.list("sources", projectId).filter(s => s.status === "ready").map(s => s.id).slice(0, 12);
    const snapshot = { project, sourceIds, model: config.model, promptVersion: "1", webSearch: input.webSearch === true, sectionId: input.sectionId || null };
    const requested = sections.filter(([key]) => snapshot.sectionId ? key === snapshot.sectionId : project.enabledSections.includes(key));
    const run = store.put("runs", {
      id: id(), projectId, requestId: input.clientRequestId, status: "queued", input: snapshot,
      fingerprint: hash(JSON.stringify(snapshot)), createdAt: now(), updatedAt: now(), calls: [], warnings: [],
      budget: { maxCalls: config.maxCalls, maxMs: config.maxMinutes * 60000 }, elapsedMs: 0,
      steps: [{ key: "collect", label: "资料采集", status: "pending" }, ...requested.map(([key, label]) => ({ key, label, status: "pending" }))]
    });
    launch(run);
    return run;
  }
  function launch(run) {
    const controller = new AbortController();
    active = { id: run.id, controller };
    void execute(run, controller).catch(error => {
      run.status = "failed"; run.error = error.message; emit(run, "run.failed");
    }).finally(() => { active = null; });
  }
  async function execute(run, controller) {
    const started = Date.now();
    const remaining = run.budget.maxMs - run.elapsedMs;
    requireValue(remaining > 0, "运行已达到累计时间上限", "BUDGET_EXCEEDED");
    const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(remaining)]);
    run.status = "running"; run.error = null; emit(run, "run.started");
    try {
      for (const step of run.steps) {
        if (step.status === "succeeded") continue;
        signal.throwIfAborted();
        step.status = "running"; step.error = null; step.attempt = (step.attempt || 0) + 1; emit(run);
        try {
          if (step.key === "collect") {
            step.sourceIds ||= [...run.input.sourceIds];
            if (run.input.webSearch && !step.searched) {
              try {
                const found = await search(`${run.input.project.material} ${run.input.project.question}`, signal);
                if (!found.length) run.warnings.push("公开搜索未返回可用来源，可手动补充资料。");
                for (const item of found) {
                  signal.throwIfAborted();
                  if (step.sourceIds.length >= 12) break;
                  const source = await addSource(store, config, run.projectId, item, signal);
                  if (source.status === "ready") step.sourceIds.push(source.id);
                  else run.warnings.push(`来源获取失败：${source.title}`);
                  emit(run, "source.ready");
                }
              } catch (error) { signal.throwIfAborted(); run.warnings.push(`搜索失败：${error.message}`); }
              step.searched = true;
            }
            requireValue(step.sourceIds.length, "没有可用正文。请在资料页添加原文后新建运行", "NO_EVIDENCE", 422);
            const all = store.list("evidence", run.projectId).filter(e => step.sourceIds.includes(e.sourceId));
            for (const e of all) {
              const body = sourceBody(config, store.get("sources", e.sourceId));
              requireValue(hash(body) === e.locator.contentHash && body.slice(e.locator.start, e.locator.end) === e.quote, "原文文件与证据快照不一致", "INVALID_CITATION", 422);
            }
            step.evidenceIds = all.map(e => e.id);
          } else {
            requireValue(run.calls.length < run.budget.maxCalls, "达到模型调用上限", "BUDGET_EXCEEDED", 422);
            const collect = run.steps.find(s => s.key === "collect");
            requireValue(collect.status === "succeeded", "缺少已验证的资料", "NO_EVIDENCE", 422);
            const evidence = collect.evidenceIds.map(key => store.get("evidence", key));
            const terms = `${step.label} ${run.input.project.material}`.split(/\s+/);
            const ranked = evidence.map((e, i) => ({ e, i, score: terms.filter(term => e.quote.includes(term)).length })).sort((a, b) => b.score - a.score || a.i - b.i);
            const chosen = ranked.slice(0, 18).map(item => item.e);
            let correction = null;
            for (let attempt = 0; attempt < 3; attempt++) {
              signal.throwIfAborted();
              requireValue(run.calls.length < run.budget.maxCalls, "达到模型调用上限", "BUDGET_EXCEEDED", 422);
              const call = { id: id(), stepKey: step.key, model: run.input.model, status: "running", startedAt: now(), usage: null };
              run.calls.push(call); emit(run, "usage.updated");
              let retryError;
              try {
                const result = await generate({ ...config, model: run.input.model }, { project: run.input.project, section: step.label, evidence: chosen, correction }, signal);
                call.status = "succeeded"; call.usage = result.usage; call.requestId = result.requestId;
                step.output = { sectionId: step.key, heading: step.label, ...result.output };
              } catch (error) {
                call.status = signal.aborted || ["TimeoutError", "AbortError", "TypeError"].includes(error.name) ? "unknown" : "failed";
                const repair = ["MODEL_OUTPUT_INVALID", "INVALID_CITATION"].includes(error.code) && !correction;
                if (repair) correction = `前次输出未通过校验：${error.message}。请严格使用给定证据与结构重新输出。`;
                if (!signal.aborted && attempt < 2 && (error.retryable || repair)) retryError = error;
                else throw error;
              } finally { call.durationMs = Date.now() - new Date(call.startedAt).getTime(); emit(run, "usage.updated"); }
              if (!retryError) break;
              const waitMs = retryError.retryAfterMs ?? 500 * (2 ** attempt);
              requireValue(Number.isFinite(waitMs) && waitMs < run.budget.maxMs - run.elapsedMs - (Date.now() - started), "重试等待超过剩余运行时间", "BUDGET_EXCEEDED", 422);
              await delay(waitMs, undefined, { signal });
            }
          }
          step.status = "succeeded"; emit(run, "section.ready");
        } catch (error) {
          step.status = signal.aborted ? "cancelled" : "failed"; step.error = error.message; emit(run);
          if (step.key === "collect" || signal.aborted || error.code === "BUDGET_EXCEEDED") throw error;
        }
      }
      run.status = run.steps.every(s => s.status === "succeeded") ? "succeeded" : run.steps.some(s => s.output) ? "partial" : "failed";
    } catch (error) {
      run.error = signal.aborted ? (controller.signal.aborted ? "已取消；已发送请求可能已产生用量" : "运行超时；已发送请求的用量可能未知") : error.message;
      run.status = controller.signal.aborted ? "cancelled" : run.steps.some(s => s.output) ? "partial" : "failed";
    } finally {
      run.elapsedMs += Date.now() - started;
      run.updatedAt = now();
      const content = run.steps.filter(s => s.output).map(s => s.output);
      if (content.length) {
        const version = store.put("versions", { id: id(), projectId: run.projectId, parentId: null, origin: "model", content, createdAt: now(), runId: run.id });
        run.versionId = version.id;
      }
      emit(run, "run.finished");
    }
  }
  function resume(runId) {
    requireValue(!active, "已有研究正在执行", "RUN_ACTIVE", 409);
    const run = store.get("runs", runId);
    requireValue(["interrupted", "failed", "partial", "cancelled"].includes(run.status), "当前运行不能恢复");
    requireValue(run.elapsedMs < run.budget.maxMs && run.calls.length < run.budget.maxCalls, "已达到预算上限，请创建新运行", "BUDGET_EXCEEDED");
    requireValue(config.apiKey, "请先配置模型连接", "MODEL_NOT_CONFIGURED");
    launch(run); return run;
  }
  function cancel(runId) {
    const run = store.get("runs", runId);
    if (active?.id === runId) active.controller.abort();
    return run;
  }
  return { start, resume, cancel, stop: () => active?.controller.abort() };
}
