import { id, now } from "./db.mjs";
import { projectInput, validSections, requireValue, reviews } from "../shared/contracts.mjs";

export function createProject(store, input) {
  const fields = projectInput(input); validSections(fields.enabledSections);
  return store.transaction(() => {
    const project = store.put("projects", { ...fields, id: id(), revision: 1, createdAt: now(), updatedAt: now(), archivedAt: null });
    store.put("drafts", { projectId: project.id, revision: 1, baseVersionId: null, content: [], updatedAt: now() });
    return project;
  });
}
export function updateProject(store, projectId, input) {
  return store.transaction(() => {
    const current = store.get("projects", projectId);
    requireValue(input.revision === current.revision, "项目已在其他页面更新，请刷新", "REVISION_CONFLICT", 409);
    const fields = projectInput({ ...current, ...input, mode: current.mode }); validSections(fields.enabledSections);
    return store.put("projects", { ...current, ...fields, archivedAt: input.archivedAt === undefined ? current.archivedAt : (input.archivedAt ? now() : null), revision: current.revision + 1, updatedAt: now() });
  });
}
export function validateContent(store, projectId, content) {
  requireValue(Array.isArray(content) && content.length <= 6, "报告章节结构无效");
  const known = new Map(store.list("evidence", projectId).map(e => [e.id, e]));
  const seen = new Set();
  const paragraphIds = new Set();
  for (const section of content) {
    validSections([section.sectionId]);
    requireValue(!seen.has(section.sectionId), "章节重复"); seen.add(section.sectionId);
    requireValue(typeof section.heading === "string" && section.heading.length <= 100 && Array.isArray(section.paragraphs) && section.paragraphs.length <= 100, "章节格式无效");
    requireValue(Array.isArray(section.gaps) && section.gaps.every(g => typeof g === "string" && g.length <= 5000), "待核验项无效");
    for (const p of section.paragraphs) {
      requireValue(typeof p.text === "string" && p.text.length <= 30000 && typeof p.id === "string", "段落内容无效");
      requireValue(p.id.length > 0 && p.id.length <= 100 && !paragraphIds.has(p.id), "段落 ID 重复或无效"); paragraphIds.add(p.id);
      requireValue(["fact", "analysis", "hypothesis"].includes(p.kind) && reviews.includes(p.review), "结论状态无效");
      requireValue(Array.isArray(p.evidenceIds) && p.evidenceIds.every(key => known.has(key)), "引用不存在或属于其他项目", "INVALID_CITATION", 422);
    }
  }
}
export function saveDraft(store, projectId, input) {
  return store.transaction(() => {
    const current = store.get("drafts", projectId);
    requireValue(input.revision === current.revision, "另一页面已更新报告；你的修改仍保留在编辑框，请另存或重新载入", "REVISION_CONFLICT", 409);
    validateContent(store, projectId, input.content);
    const old = new Map(current.content.flatMap(s => s.paragraphs).map(p => [p.id, p]));
    const content = structuredClone(input.content);
    for (const p of content.flatMap(s => s.paragraphs)) {
      const prev = old.get(p.id);
      if (!prev || prev.text !== p.text || prev.kind !== p.kind || JSON.stringify(prev.evidenceIds) !== JSON.stringify(p.evidenceIds)) p.review = "unreviewed";
    }
    const draft = store.put("drafts", { ...current, content, revision: current.revision + 1, updatedAt: now() });
    const project = store.get("projects", projectId);
    store.put("projects", { ...project, updatedAt: now() });
    return draft;
  });
}
export function snapshot(store, projectId, revision) {
  return store.transaction(() => {
    const draft = store.get("drafts", projectId);
    requireValue(revision === draft.revision, "保存版本冲突，请刷新", "REVISION_CONFLICT", 409);
    const version = store.put("versions", { id: id(), projectId, parentId: draft.baseVersionId, origin: store.get("projects", projectId).mode === "demo" ? "demo" : "manual", content: draft.content, createdAt: now() });
    store.put("drafts", { ...draft, baseVersionId: version.id, revision: draft.revision + 1 });
    return version;
  });
}
