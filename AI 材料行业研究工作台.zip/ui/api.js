export async function api(path, method = "GET", data) {
  const response = await fetch(`/api${path}`, { method, headers: data === undefined ? {} : { "content-type": "application/json" }, body: data === undefined ? undefined : JSON.stringify(data) });
  const payload = await response.json();
  if (!response.ok) { const error = new Error(payload.error?.message || "请求失败"); error.code = payload.error?.code; throw error; }
  return payload.data;
}
export const esc = (value = "") => String(value).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
export const icon = name => `<img class="icon" src="/icons/${name}.svg" alt="">`;
export const date = value => value ? new Date(value).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }) : "未知";
export const labels = { succeeded: "已完成", pending: "待开始", queued: "待开始", running: "执行中", partial: "部分完成", failed: "失败", cancelled: "已取消", interrupted: "已中断", ready: "正文可用", unreviewed: "待核验", supported: "支持", unsupported: "不支持", fact: "原文事实", analysis: "分析判断", hypothesis: "待验证假设" };
export function badge(status) { return `<span class="badge ${esc(status)}">${esc(labels[status] || status)}</span>`; }
