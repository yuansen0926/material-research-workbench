import { api, esc, icon, date, labels, badge } from "./api.js";
import { sections } from "/shared/contracts.mjs";

const main = document.querySelector("#main");
const dialog = document.querySelector("#dialog");
let project, draft, sources = [], runs = [], versions = [], settings;
let routeSerial = 0, stream, editing = null, dirty = false, currentHash = "", saving = false, autosave, editBaseline;
const notice = message => {
  const node = document.querySelector("#notice"); node.textContent = message; node.hidden = false;
  clearTimeout(notice.timer); notice.timer = setTimeout(() => { node.hidden = true; }, 6000);
};
function fail(error) {
  notice(error.message);
  const target = dialog.open ? dialog.querySelector(".form-error") : document.querySelector(".save-state");
  if (target) { target.textContent = error.message; target.classList.add("error-text"); }
}
function modal(title, content, side = false) {
  dialog.className = side ? "evidence-dialog" : "";
  dialog.innerHTML = `<header><h2>${esc(title)}</h2><button type="button" class="icon-button" data-action="close" title="关闭" aria-label="关闭">${icon("x")}</button></header>${content}<p class="form-error" role="alert"></p>`;
  dialog.showModal();
}
const button = (action, title, name, primary = false, extra = "") => `<button class="${primary ? "primary" : ""}" data-action="${action}" ${extra}>${icon(name)}${title}</button>`;
const empty = (title, detail, action = "") => `<div class="empty"><img src="/icons/files.svg" alt=""><h2>${title}</h2><p>${detail}</p>${action}</div>`;
function backupKey() { return `material-workbench-editor:${project.id}`; }
function backupEditor() {
  if (!editing) return;
  try {
    localStorage.setItem(backupKey(), JSON.stringify({ sectionId: editing, texts: editorTexts(), savedAt: new Date().toISOString() }));
  } catch { /* The visible editor remains the source of unsaved text. */ }
}
function editorTexts() { return [...main.querySelectorAll("[data-paragraph]")].map(el => ({ id: el.dataset.paragraph, text: el.value })); }
function clearBackup() { try { localStorage.removeItem(backupKey()); } catch {} }

async function route() {
  clearTimeout(autosave);
  if (saving) {
    notice("正在保存，请完成后切换页面");
    history.replaceState(null, "", currentHash); return;
  }
  if (dirty && !confirm("修改尚未保存。离开后可从本机恢复草稿，仍要离开吗？")) {
    history.replaceState(null, "", currentHash); return;
  }
  currentHash = location.hash || "#/projects"; dirty = false; editing = null;
  stream?.close(); stream = null;
  const serial = ++routeSerial;
  const parts = currentHash.slice(2).split("/");
  main.innerHTML = `<div class="loading">正在读取…</div>`;
  try {
    settings ||= await api("/settings/status");
    document.querySelector("#model-status").textContent = settings.configured ? settings.model : "模型未配置";
    if (parts[0] === "settings") return renderSettings();
    if (parts[0] === "projects" && parts[1] && parts[1] !== "new") {
      const pid = encodeURIComponent(parts[1]);
      const result = await Promise.all([api(`/projects/${pid}`), api(`/projects/${pid}/draft`), api(`/projects/${pid}/sources`), api(`/projects/${pid}/runs`), api(`/projects/${pid}/versions`)]);
      if (serial !== routeSerial) return;
      [project, draft, sources, runs, versions] = result;
      renderWorkspace(parts[2] || "overview");
    } else {
      const data = await api("/projects");
      if (serial !== routeSerial) return;
      renderProjects(data.items);
      if (parts[1] === "new") openProjectForm();
    }
  } catch (error) {
    if (serial !== routeSerial) return;
    main.innerHTML = empty("暂时无法打开", esc(error.message), button("refresh", "重试", "refresh-cw"));
  }
}
function renderProjects(items) {
  project = null;
  main.innerHTML = `<header class="page-header"><div><div class="eyebrow">WORKSPACE</div><h1>研究项目</h1></div><div class="actions">${button("demo", "演示案例", "book-open")}${button("new", "新建研究", "plus", true)}</div></header>
    <div class="library">
      <div class="library-toolbar"><label class="search">${icon("search")}<input id="project-search" type="search" placeholder="搜索课题、材料" aria-label="搜索项目"></label>
      <label>项目范围 <select id="archive-filter"><option value="false">当前项目</option><option value="true">已归档</option></select></label></div>
      <div class="list-heading"><span>课题 / 研究问题</span><span>材料</span><span>更新于</span><span></span></div>
      <div id="project-list"></div>
    </div>`;
  projectRows(items);
}
function projectRows(items) {
  document.querySelector("#project-list").innerHTML = items.length ? items.map(p => `
    <a class="project-row" href="#/projects/${p.id}/overview"><span class="project-title">${icon("file-text")}<span><strong>${esc(p.title)}</strong><small>${esc(p.question)}</small>${p.mode === "demo" ? `<span class="badge demo">演示数据</span>` : ""}</span></span><span>${esc(p.material)}</span><time>${date(p.updatedAt)}</time>${icon("arrow-up-right")}</a>`).join("") : empty("开始一项研究", "当前范围内没有项目", button("new", "新建研究", "plus", true));
}
function openProjectForm(edit = false) {
  const p = edit ? project : { title: "", material: "", question: "", scope: "中国市场", profile: "", enabledSections: sections.map(([key]) => key) };
  modal(edit ? "编辑研究课题" : "新建研究", `<form id="project-form" data-edit="${edit}">
    <label>课题名称<input name="title" maxlength="200" required value="${esc(p.title)}" placeholder="例如：磷酸锰铁锂产业化路径"></label>
    <div class="form-grid"><label>材料方向<input name="material" maxlength="100" required value="${esc(p.material)}"></label><label>时间与区域范围<input name="scope" maxlength="2000" value="${esc(p.scope)}"></label></div>
    <label>研究问题<textarea name="question" maxlength="5000" rows="3" required>${esc(p.question)}</textarea></label>
    <details><summary>企业背景与报告章节</summary><label>企业背景<textarea name="profile" maxlength="5000" rows="2">${esc(p.profile)}</textarea></label>
    <fieldset><legend>报告章节</legend><div class="checks">${sections.map(([key, label]) => `<label><input type="checkbox" name="section" value="${key}" ${p.enabledSections.includes(key) ? "checked" : ""}>${label}</label>`).join("")}</div></fieldset></details>
    <footer><button type="button" data-action="close">取消</button><button class="primary" type="submit">${icon("check")}保存课题</button></footer></form>`);
}
function renderWorkspace(view) {
  const available = ["overview", "sources", "report", "runs", "setup"];
  if (!available.includes(view)) view = "overview";
  main.innerHTML = `
    <header class="workspace-header"><div class="breadcrumb"><a href="#/projects">研究项目</a><span>/</span><span>${esc(project.material)}</span></div>
    <div class="workspace-title"><div><h1>${esc(project.title)}</h1><div class="subline">${project.mode === "demo" ? badge("演示数据") : badge("研究草稿")}<span class="save-state" aria-live="polite">更新于 ${date(draft.updatedAt)}</span></div></div>
    <div class="actions">${button("edit-project", "", "sliders-horizontal", false, 'title="编辑课题" aria-label="编辑课题"')}${button("export", "导出", "download", false, draft.content.length ? "" : "disabled")}${button("plan", "研究计划", "play", true, project.mode === "demo" ? 'disabled title="演示项目不执行真实研究"' : "")}</div></div>
    <nav class="workspace-tabs" aria-label="项目视图">${[["overview", "概览"], ["sources", "资料"], ["report", "报告"], ["runs", "执行记录"]].map(([key, name]) => `<a href="#/projects/${project.id}/${key}" ${key === view ? 'aria-current="page"' : ""}>${name}${key === "sources" ? `<span>${sources.length}</span>` : ""}</a>`).join("")}</nav></header>
    <div id="view"></div>`;
  if (view === "report") renderReport();
  else if (view === "sources") renderSources();
  else if (view === "runs") renderRuns();
  else renderOverview();
}
function renderOverview() {
  const paragraphs = draft.content.flatMap(s => s.paragraphs);
  document.querySelector("#view").innerHTML = `<div class="overview">
    <section class="research-brief"><div class="eyebrow">RESEARCH QUESTION</div><h2>${esc(project.question)}</h2><div class="brief-meta"><span>${icon("map-pin")}${esc(project.scope || "范围未指定")}</span><span>${icon("flask-conical")}${esc(project.material)}</span></div>${project.mode === "demo" ? `<p class="warning">演示数据 · 自编案例，不代表真实企业或行业研究。</p>` : ""}</section>
    <div class="metrics">
      <a href="#/projects/${project.id}/sources"><strong>${sources.filter(s => s.status === "ready").length}<small> / ${sources.length}</small></strong><span>可用正文 / 全部来源</span></a>
      <a href="#/projects/${project.id}/report"><strong>${draft.content.length}<small> / ${project.enabledSections.length}</small></strong><span>已保存章节</span></a>
      <a href="#/projects/${project.id}/report"><strong>${paragraphs.filter(p => p.review === "unreviewed").length}</strong><span>待核验结论</span></a>
      <a href="#/projects/${project.id}/runs"><strong>${runs.length}</strong><span>研究运行记录</span></a>
    </div>
    <div class="overview-columns"><section><div class="section-heading"><h2>研究进展</h2>${icon("activity")}</div>
    ${draft.content.length ? draft.content.slice(0, 3).map(s => `<a class="finding" href="#/projects/${project.id}/report"><span>${esc(s.heading)}</span><p>${esc(s.paragraphs[0]?.text || "暂无内容")}</p>${icon("arrow-right")}</a>`).join("") : empty("课题已就绪", "尚未生成报告", button("add-source", "添加原文资料", "plus", true))}</section>
    <section class="context-panel"><div class="section-heading"><h2>研究范围</h2>${button("edit-project", "", "pencil", false, 'title="编辑" aria-label="编辑研究范围"')}</div><dl><dt>企业背景</dt><dd>${esc(project.profile || "未指定")}</dd><dt>报告章节</dt><dd>${sections.filter(([key]) => project.enabledSections.includes(key)).map(([, label]) => esc(label)).join("、")}</dd><dt>下一步</dt><dd>${project.mode === "demo" ? "核对原文，编辑报告，保存版本。" : !sources.some(s => s.status === "ready") ? "添加原文，或确认联网研究计划。" : !draft.content.length ? "确认计划后开始生成。" : "核对引用并完善待验证事项。"}</dd></dl>
    ${button("archive", project.archivedAt ? "恢复项目" : "归档项目", "archive")}</section></div>
    </div>`;
}
function renderSources() {
  document.querySelector("#view").innerHTML = `<div class="source-page"><div class="section-heading"><h2>来源资料 <small>${sources.length}</small></h2>${button("add-source", "添加资料", "plus", true)}</div>
    <div class="library-toolbar"><label class="search">${icon("search")}<input id="source-search" type="search" placeholder="搜索资料标题" aria-label="搜索资料"></label><select id="source-filter" aria-label="资料状态"><option value="">全部状态</option><option value="ready">正文可用</option><option value="failed">采集失败</option></select></div><div id="source-list"></div></div>`;
  sourceRows();
}
function sourceRows() {
  const q = document.querySelector("#source-search").value.toLowerCase(), status = document.querySelector("#source-filter").value;
  const items = sources.filter(s => s.title.toLowerCase().includes(q) && (!status || status === s.status));
  document.querySelector("#source-list").innerHTML = items.length ? items.map(s => `<article class="source-row"><div class="source-symbol">${icon(s.url ? "globe" : "file-text")}</div><div><h3><button class="text-button" data-action="source" data-id="${s.id}">${esc(s.title)}</button></h3><p>${s.url ? esc(new URL(s.url).hostname) : "用户提供文字"} · 采集于 ${date(s.fetchedAt)}</p>${s.error ? `<p class="error-text">${esc(s.error)}</p>` : ""}</div><div class="source-actions">${badge(s.status)}${s.status === "failed" ? button("retry-source", "", "refresh-cw", false, `data-id="${s.id}" title="重试采集" aria-label="重试采集"`) : ""}</div></article>`).join("") : empty("没有匹配的资料", "更改筛选条件，或添加原文资料");
}
function sourceModal() {
  modal("添加研究资料", `<form id="source-form"><div class="mode-select"><label><input type="radio" name="sourceMode" value="text" checked>粘贴正文</label><label><input type="radio" name="sourceMode" value="url">网页链接</label></div>
    <div id="text-fields"><label>资料标题<input name="title" maxlength="500" placeholder="报告名称、公司公告或访谈记录"></label><label>原文<textarea name="text" rows="9" maxlength="200000"></textarea></label></div>
    <div id="url-fields" hidden><label>网页链接<input type="url" name="url" placeholder="https://"></label></div>
    <footer><button type="button" data-action="close">取消</button><button class="primary" type="submit">${icon("plus")}添加资料</button></footer></form>`);
}
function renderReport() {
  const saveState = main.querySelector(".save-state");
  if (saveState) { saveState.textContent = `已保存 ${date(draft.updatedAt)}`; saveState.classList.remove("error-text"); }
  const exportButton = main.querySelector('[data-action="export"]');
  if (exportButton) exportButton.disabled = !draft.content.length;
  document.querySelector("#view").innerHTML = `<div class="report-toolbar"><span>${icon("file-check-2")}工作草稿 <span class="muted">r${draft.revision}</span></span><div class="actions">${button("versions", "版本历史", "history")}${button("snapshot", "保存版本", "save", false, draft.content.length ? "" : "disabled")}${button("print", "", "printer", false, 'title="打印" aria-label="打印"')}</div></div>
    ${draft.content.length ? `<div class="report-layout"><nav class="section-nav" aria-label="报告章节"><span class="eyebrow">CONTENTS</span>${draft.content.map((s, i) => `<button data-action="jump" data-id="${s.sectionId}"><span>${String(i + 1).padStart(2, "0")}</span>${esc(s.heading)}</button>`).join("")}</nav><article class="document"><header class="document-cover"><span class="eyebrow">MATERIAL RESEARCH</span><h2>${esc(project.title)}</h2><p>${esc(project.scope)} · ${project.mode === "demo" ? "演示数据" : "研究初稿"}</p></header>${draft.content.map(sectionHtml).join("")}<footer class="document-footer">研序 · ${project.mode === "demo" ? "自编演示案例" : "请核验关键结论"}</footer></article></div>` : empty("尚未保存报告", "开始写作，或查看生成的候选版本。", `${button("blank-report", "创建写作草稿", "file-pen-line", true)} ${button("versions", "查看候选版本", "history")}`)}`;
  try {
    const recovered = JSON.parse(localStorage.getItem(backupKey()) || "null");
    if (recovered && draft.content.some(s => s.sectionId === recovered.sectionId)) {
      const bar = document.createElement("div"); bar.className = "recovery";
      bar.innerHTML = `发现未确认的本机编辑草稿 ${button("recover", "恢复编辑", "rotate-ccw")}${button("discard-recovery", "丢弃", "x")}`;
      document.querySelector("#view").prepend(bar);
    }
  } catch {}
}
function sectionHtml(s, index) {
  return `<section class="report-section" id="section-${s.sectionId}" data-section="${s.sectionId}">
    <header><div><span class="section-number">${String(index + 1).padStart(2, "0")}</span><h3>${esc(s.heading)}</h3></div><div class="actions no-print">${button("edit-section", "", "pencil", false, `data-id="${s.sectionId}" title="编辑章节" aria-label="编辑${esc(s.heading)}"`)}${project.mode === "real" ? button("rewrite", "", "refresh-cw", false, `data-id="${s.sectionId}" title="重新研究此章" aria-label="重新研究${esc(s.heading)}"`) : ""}</div></header>
    <div class="section-content">${s.paragraphs.map((p, i) => `<div class="paragraph"><div class="paragraph-meta">${badge(p.kind)}${badge(p.review)}</div><p>${esc(p.text)}</p><div class="references">${p.evidenceIds.map((key, j) => `<button data-action="evidence" data-id="${key}" data-paragraph-id="${p.id}" title="查看原文证据">${icon("quote")}原文 ${j + 1}</button>`).join("")}</div></div>`).join("")}
    ${s.gaps.length ? `<div class="gaps"><strong>${icon("circle-help")}待核验</strong><ul>${s.gaps.map(g => `<li>${esc(g)}</li>`).join("")}</ul></div>` : ""}</div></section>`;
}
async function editSection(sectionId, recovered) {
  if (editing) { notice("请先完成当前章节编辑"); return; }
  const section = draft.content.find(s => s.sectionId === sectionId);
  editBaseline = structuredClone(section);
  editing = sectionId; dirty = Boolean(recovered);
  const target = document.querySelector(`#section-${sectionId} .section-content`);
  target.innerHTML = `<div class="editor">${section.paragraphs.map(p => `<label>${esc(labels[p.kind])}<textarea rows="5" data-paragraph="${p.id}">${esc(recovered?.texts.find(item => item.id === p.id)?.text ?? p.text)}</textarea></label>`).join("")}<div class="editor-footer"><span class="editor-status" aria-live="polite">${dirty ? "本机草稿已恢复，尚未保存" : "未修改"}</span><div class="actions">${button("revert-edit", "撤销本次编辑", "undo-2")}${button("cancel-edit", "完成编辑", "x")}${button("save-edit", "保存", "check", true)}</div></div><div class="conflict-actions" hidden>${button("fork-edit", "另存为独立版本", "copy")}${button("reload-draft", "载入服务端草稿", "refresh-cw")}</div></div>`;
  target.querySelector("textarea")?.focus();
}
async function saveEditor() {
  if (!editing || saving || !dirty) return;
  saving = true; clearTimeout(autosave);
  const status = document.querySelector(".editor-status");
  const before = JSON.stringify(editorTexts());
  const content = structuredClone(draft.content);
  const section = content.find(s => s.sectionId === editing);
  for (const item of editorTexts()) section.paragraphs.find(p => p.id === item.id).text = item.text;
  if (status) status.textContent = "保存中…";
  try {
    draft = await api(`/projects/${project.id}/draft`, "PUT", { revision: draft.revision, content });
    dirty = before !== JSON.stringify(editorTexts());
    if (status) status.textContent = dirty ? "有新修改，待保存" : "已保存";
    if (!dirty) clearBackup();
    document.querySelector(".save-state").textContent = `已保存 ${date(draft.updatedAt)}`;
    if (dirty) autosave = setTimeout(() => saveEditor().catch(fail), 800);
  } catch (error) {
    if (status) { status.textContent = error.message; status.classList.add("error-text"); }
    if (error.code === "REVISION_CONFLICT") document.querySelector(".conflict-actions").hidden = false;
    backupEditor(); throw error;
  } finally { saving = false; }
}
async function evidencePanel(key, paragraphId) {
  const evidence = await api(`/projects/${project.id}/evidence/${key}`);
  const p = draft.content.flatMap(s => s.paragraphs).find(p => p.id === paragraphId);
  modal("原文证据", `<div class="evidence-body"><span class="eyebrow">SOURCE EXCERPT</span><h3>${esc(evidence.source.title)}</h3><div class="meta-line">${badge(evidence.source.status)}<span>采集于 ${date(evidence.source.fetchedAt)}</span></div><blockquote>${esc(evidence.quote)}</blockquote><dl><dt>原文位置</dt><dd>字符 ${evidence.locator.start}—${evidence.locator.end}</dd><dt>发布日期</dt><dd>${esc(evidence.source.publishedAt || "未知")}</dd></dl>${evidence.source.url && /^https?:\/\//.test(evidence.source.url) ? `<a class="external" href="${esc(evidence.source.url)}" target="_blank" rel="noreferrer">${icon("external-link")}打开来源网页</a>` : ""}
    ${p ? `<div class="review-box"><h3>此证据是否支持结论？</h3><p>${esc(p.text)}</p><label>审核结果<select id="review" data-paragraph-id="${p.id}">${["unreviewed", "supported", "partial", "unsupported"].map(status => `<option value="${status}" ${p.review === status ? "selected" : ""}>${status === "partial" ? "部分支持" : labels[status]}</option>`).join("")}</select></label>${button("save-review", "保存审核", "check", true)}</div>` : ""}</div>`, true);
}
function renderRuns() {
  document.querySelector("#view").innerHTML = `<div class="run-page"><div class="section-heading"><h2>研究运行</h2><span id="connection-status" class="muted"></span></div><div id="runs-list"></div></div>`;
  runRows();
  const current = runs.find(r => ["running", "queued"].includes(r.status));
  if (current) {
    stream = new EventSource(`/api/runs/${current.id}/events`);
    stream.onopen = () => { const el = document.querySelector("#connection-status"); if (el) el.textContent = "已连接"; };
    stream.onerror = () => { const el = document.querySelector("#connection-status"); if (el) el.textContent = "连接中断，正在重连"; };
    const serial = routeSerial;
    stream.addEventListener("update", async () => {
      try {
        const latest = await api(`/runs/${current.id}`);
        if (serial !== routeSerial) return;
        runs = runs.map(r => r.id === latest.id ? latest : r); runRows();
        if (!["running", "queued"].includes(latest.status)) { stream?.close(); stream = null; document.querySelector("#connection-status").textContent = "执行已结束"; versions = await api(`/projects/${project.id}/versions`); }
      } catch (error) { fail(error); }
    });
  }
}
function runRows() {
  document.querySelector("#runs-list").innerHTML = runs.length ? runs.map(r => {
    const tokens = r.calls.filter(c => c.usage).reduce((sum, c) => sum + (c.usage.total_tokens || 0), 0);
    return `<article class="run-record"><header><div>${badge(r.status)}<time>${date(r.createdAt)}</time></div><div class="actions">${r.versionId ? button("candidate", "查看候选报告", "file-text", false, `data-id="${r.versionId}"`) : ""}${["running", "queued"].includes(r.status) ? button("cancel-run", "取消", "square", false, `data-id="${r.id}"`) : ["partial", "failed", "cancelled", "interrupted"].includes(r.status) ? button("resume", "继续执行", "play", false, `data-id="${r.id}"`) : ""}</div></header>
    <div class="timeline">${r.steps.map((s, i) => `<div class="timeline-step ${s.status}"><span class="step-symbol">${s.status === "succeeded" ? icon("check") : String(i + 1).padStart(2, "0")}</span><div><strong>${esc(s.label)}</strong>${s.error ? `<p class="error-text">${esc(s.error)}</p>` : ""}</div>${badge(s.status)}</div>`).join("")}</div>
    ${r.error ? `<p class="warning">${esc(r.error)}</p>` : ""}${r.warnings.length ? `<details><summary>采集提示 (${r.warnings.length})</summary>${r.warnings.map(w => `<p>${esc(w)}</p>`).join("")}</details>` : ""}
    <footer><span>${r.calls.length} 次模型调用</span><span>${r.calls.some(c => c.usage) ? `${tokens} tokens（已知用量）` : "用量未知"}</span><span>${r.calls.some(c => c.status === "unknown") ? "包含结果未知的调用" : ""}</span><span>${Math.round(r.elapsedMs / 1000)} 秒 · 已执行时间</span></footer></article>`;
  }).join("") : empty("暂无运行记录", project.mode === "demo" ? "此案例仅包含自编资料和报告。" : "确认研究计划后开始执行。", project.mode === "demo" ? "" : button("plan", "研究计划", "play", true));
}
async function planModal(sectionId) {
  const plan = await api(`/projects/${project.id}/plan`, "POST", {});
  modal(sectionId ? "重新研究章节" : "确认研究计划", `<form id="run-form" data-section="${sectionId || ""}"><p class="plan-question">${esc(project.question)}</p><ol class="plan-list">${plan.sections.filter(([key]) => !sectionId || key === sectionId).map(([, label]) => `<li>${esc(label)}</li>`).join("")}</ol><p>已保存 ${plan.availableSources} 份原文</p><label class="checkbox"><input type="checkbox" name="webSearch" ${plan.availableSources ? "" : "checked"}>补充公开网页搜索</label><p class="muted">外部模型将接收研究问题和相关原文片段。上限 ${settings.maxCalls} 次模型调用、${settings.maxMinutes} 分钟。</p>${!settings.configured ? '<p class="warning">模型尚未配置，请前往设置。</p>' : ""}<footer><button type="button" data-action="close">取消</button><button class="primary" type="submit" ${settings.configured ? "" : "disabled"}>${icon("play")}确认并开始</button></footer></form>`);
}
async function versionModal(selected) {
  versions = await api(`/projects/${project.id}/versions`);
  if (selected) {
    const v = await api(`/projects/${project.id}/versions/${selected}`);
    modal("报告版本", `<div class="version-detail"><div class="meta-line">${badge(v.origin === "model" ? "模型候选" : v.origin === "demo" ? "演示版本" : "人工版本")}<span>${date(v.createdAt)}</span></div>${v.content.map(s => `<section><h3>${esc(s.heading)}</h3><div class="comparison"><div><small>当前草稿</small><p>${esc(draft.content.find(c => c.sectionId === s.sectionId)?.paragraphs.map(p => p.text).join("\n\n") || "暂无")}</p></div><div><small>此版本</small><p>${esc(s.paragraphs.map(p => p.text).join("\n\n"))}</p></div></div>${s.gaps.length ? `<p class="warning">${esc(s.gaps.join("；"))}</p>` : ""}</section>`).join("")}<footer>${button("versions", "返回历史", "arrow-left")}${button("adopt", "采用此版本的章节", "check", true, `data-id="${v.id}"`)}</footer></div>`);
  } else modal("版本历史", versions.length ? `<div class="version-list">${versions.map(v => `<button data-action="candidate" data-id="${v.id}"><span>${v.origin === "model" ? "模型候选" : v.origin === "demo" ? "演示版本" : "人工保存"} · ${v.sectionCount} 章</span><time>${date(v.createdAt)}</time>${icon("chevron-right")}</button>`).join("")}</div>` : empty("暂无版本", "保存草稿或完成研究后查看。"));
}
function renderSettings() {
  project = null;
  main.innerHTML = `<header class="page-header"><div><div class="eyebrow">PREFERENCES</div><h1>工作台设置</h1></div></header><div class="settings-page">
    <section><div class="section-heading"><h2>模型连接</h2>${badge(settings.configured ? "已配置" : "未配置")}</div><dl><dt>接口</dt><dd>${settings.endpoint === "chat" ? "OpenAI 兼容 Chat Completions" : "OpenAI Responses API"}</dd><dt>模型</dt><dd>${esc(settings.model)}</dd><dt>Base URL</dt><dd class="mono">${esc(settings.apiBaseUrl)}</dd><dt>调用上限</dt><dd>${settings.maxCalls} 次 / ${settings.maxMinutes} 分钟</dd></dl><p class="muted">配置文件：项目根目录 .env · 修改后重启服务</p><pre>OPENAI_API_KEY=你的密钥\nOPENAI_BASE_URL=${esc(settings.apiBaseUrl)}\nOPENAI_ENDPOINT=${esc(settings.endpoint)}\nOPENAI_MODEL=${esc(settings.model)}</pre>${button("check-model", "检查连接", "plug-zap", true)}</section>
    <section><h2>本地数据</h2><dl><dt>数据目录</dt><dd class="mono">${esc(settings.dataDirectory)}</dd><dt>存储方式</dt><dd>SQLite + 原文文本快照</dd></dl><p class="muted">备份前停止服务，完整保留数据目录。模型调用与网页检索需要联网。</p></section>
    <section><h2>演示案例</h2>${button("demo", "打开演示案例", "book-open")}</section></div>`;
}

document.addEventListener("click", async event => {
  const node = event.target.closest("[data-action]");
  if (!node || node.disabled) return;
  const action = node.dataset.action, key = node.dataset.id;
  try {
    if (action === "close") { dialog.close(); return; }
    if (action === "refresh") { await route(); return; }
    if (action === "new") { openProjectForm(); return; }
    if (action === "edit-project") { openProjectForm(true); return; }
    if (action === "demo") { const p = await api("/demo", "POST", {}); location.hash = `#/projects/${p.id}/overview`; return; }
    if (action === "archive") { await api(`/projects/${project.id}`, "PATCH", { revision: project.revision, archivedAt: !project.archivedAt }); location.hash = "#/projects"; return; }
    if (action === "add-source") { sourceModal(); return; }
    if (action === "source") {
      const s = await api(`/projects/${project.id}/sources/${key}`);
      modal(s.title, `<div class="source-preview">${badge(s.status)}<pre>${esc(s.text || s.error)}</pre></div>`, true); return;
    }
    if (action === "retry-source") {
      node.disabled = true; await api(`/projects/${project.id}/sources/${key}/retry`, "POST", {}); sources = await api(`/projects/${project.id}/sources`); sourceRows(); return;
    }
    if (action === "jump") { document.querySelector(`#section-${key}`)?.scrollIntoView({ block: "start", behavior: "smooth" }); return; }
    if (action === "edit-section") { await editSection(key); return; }
    if (action === "blank-report") {
      const content = sections.filter(([key]) => project.enabledSections.includes(key)).map(([sectionId, heading]) => ({ sectionId, heading, gaps: [], paragraphs: [{ id: crypto.randomUUID(), text: "", kind: "analysis", review: "unreviewed", evidenceIds: [] }] }));
      draft = await api(`/projects/${project.id}/draft`, "PUT", { revision: draft.revision, content });
      renderReport(); await editSection(content[0].sectionId); return;
    }
    if (action === "save-edit") { await saveEditor(); return; }
    if (action === "cancel-edit") {
      if (saving) return notice("正在保存");
      if (dirty) await saveEditor();
      editing = null; clearBackup(); renderReport(); return;
    }
    if (action === "revert-edit") {
      if (saving) return notice("正在保存");
      clearTimeout(autosave);
      if (!confirm("撤销进入编辑以来的文字修改？已保存的历史版本会保留。")) return;
      const content = structuredClone(draft.content);
      content[content.findIndex(s => s.sectionId === editing)] = editBaseline;
      draft = await api(`/projects/${project.id}/draft`, "PUT", { revision: draft.revision, content });
      dirty = false; editing = null; clearBackup(); renderReport(); return;
    }
    if (action === "fork-edit") {
      clearTimeout(autosave);
      const content = structuredClone(draft.content), section = content.find(s => s.sectionId === editing);
      for (const item of editorTexts()) section.paragraphs.find(p => p.id === item.id).text = item.text;
      await api(`/projects/${project.id}/versions`, "POST", { content });
      dirty = false; editing = null; clearBackup();
      draft = await api(`/projects/${project.id}/draft`); renderReport(); notice("修改已另存到版本历史，服务端草稿保持不变"); return;
    }
    if (action === "reload-draft") {
      backupEditor(); clearTimeout(autosave); dirty = false; editing = null;
      draft = await api(`/projects/${project.id}/draft`); renderReport(); return;
    }
    if (action === "recover") { const recovered = JSON.parse(localStorage.getItem(backupKey())); await editSection(recovered.sectionId, recovered); document.querySelector(".recovery")?.remove(); return; }
    if (action === "discard-recovery") { clearBackup(); document.querySelector(".recovery")?.remove(); return; }
    if (["evidence", "versions", "candidate", "snapshot", "export", "plan", "rewrite", "print"].includes(action) && dirty) { await saveEditor(); if (dirty) return notice("请先保存当前编辑"); }
    if (action === "evidence") { await evidencePanel(key, node.dataset.paragraphId); return; }
    if (action === "save-review") {
      const select = dialog.querySelector("#review");
      const content = structuredClone(draft.content);
      content.flatMap(s => s.paragraphs).find(p => p.id === select.dataset.paragraphId).review = select.value;
      draft = await api(`/projects/${project.id}/draft`, "PUT", { revision: draft.revision, content });
      dialog.close(); editing = null; renderReport(); notice("审核已保存"); return;
    }
    if (action === "plan" || action === "rewrite") { await planModal(action === "rewrite" ? key : null); return; }
    if (action === "cancel-run") { await api(`/runs/${key}/cancel`, "POST", {}); notice("已请求取消"); return; }
    if (action === "resume") {
      if (!confirm("将继续未完成步骤，未知结果的模型请求可能再次产生用量。继续吗？")) return;
      await api(`/runs/${key}/resume`, "POST", {}); await route(); return;
    }
    if (action === "versions" || action === "candidate") { if (dialog.open) dialog.close(); await versionModal(action === "candidate" ? key : null); return; }
    if (action === "adopt") {
      const v = await api(`/projects/${project.id}/versions/${key}`);
      await api(`/projects/${project.id}/versions`, "POST", { draftRevision: draft.revision });
      draft = await api(`/projects/${project.id}/draft`);
      const merged = new Map(draft.content.map(s => [s.sectionId, s]));
      v.content.forEach(s => merged.set(s.sectionId, s));
      const content = sections.filter(([sid]) => merged.has(sid)).map(([sid]) => merged.get(sid));
      draft = await api(`/projects/${project.id}/draft`, "PUT", { revision: draft.revision, content });
      dialog.close(); editing = null; dirty = false; clearBackup();
      if (location.hash.endsWith("/report")) renderReport(); else location.hash = `#/projects/${project.id}/report`;
      notice("已采用，旧草稿已保存为历史版本"); return;
    }
    if (action === "snapshot" || action === "export") {
      const v = await api(`/projects/${project.id}/versions`, "POST", { draftRevision: draft.revision });
      draft = await api(`/projects/${project.id}/draft`);
      if (action === "snapshot") notice("报告版本已保存");
      else {
        const link = document.createElement("a"); link.href = `/api/projects/${project.id}/export?format=md&versionId=${v.id}`; link.download = `${project.title}.md`; link.click();
      }
      return;
    }
    if (action === "print") {
      const keys = [...new Set(draft.content.flatMap(s => s.paragraphs.flatMap(p => p.evidenceIds)))];
      const evidence = await Promise.all(keys.map(key => api(`/projects/${project.id}/evidence/${key}`)));
      const print = document.querySelector("#print-output") || document.body.appendChild(Object.assign(document.createElement("article"), { id: "print-output" }));
      print.innerHTML = `<h1>${esc(project.title)}</h1><p>${project.mode === "demo" ? "演示数据 · 自编案例" : "研究初稿 · 关键事实待人工核验"}</p>${draft.content.map(s => `<section><h2>${esc(s.heading)}</h2>${s.paragraphs.map(p => `<p>${esc(p.text)} ${p.evidenceIds.map(key => `[${keys.indexOf(key) + 1}]`).join("")}</p><small>${esc(labels[p.kind])} · ${p.review === "partial" ? "部分支持" : esc(labels[p.review])}</small>`).join("")}${s.gaps.length ? `<p>待核验：${esc(s.gaps.join("；"))}</p>` : ""}</section>`).join("")}<h2>原文证据</h2>${evidence.map((e, i) => `<section><h3>[${i + 1}] ${esc(e.source.title)}</h3><p>${esc(e.source.url || "用户提供文字")} · 发布日期 ${esc(e.source.publishedAt || "未知")} · 采集 ${date(e.source.fetchedAt)}</p><blockquote>${esc(e.quote)}</blockquote></section>`).join("")}`;
      window.print(); return;
    }
    if (action === "check-model") { node.disabled = true; await api("/settings/check", "POST", {}); notice("模型连接正常"); return; }
  } catch (error) { fail(error); }
  finally { if (node.isConnected) node.disabled = false; }
});
document.addEventListener("submit", async event => {
  const form = event.target;
  if (!["project-form", "source-form", "run-form"].includes(form.id)) return;
  event.preventDefault();
  const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
  const data = new FormData(form);
  try {
    if (form.id === "project-form") {
      const input = Object.fromEntries(data); input.enabledSections = data.getAll("section");
      const edit = form.dataset.edit === "true";
      if (edit) input.revision = project.revision;
      const p = await api(edit ? `/projects/${project.id}` : "/projects", edit ? "PATCH" : "POST", input);
      dialog.close();
      if (location.hash === `#/projects/${p.id}/overview`) await route(); else location.hash = `#/projects/${p.id}/overview`;
    }
    if (form.id === "source-form") {
      const input = data.get("sourceMode") === "url" ? { url: data.get("url") } : { title: data.get("title"), text: data.get("text") };
      const source = await api(`/projects/${project.id}/sources`, "POST", input);
      dialog.close(); notice(source.status === "ready" ? "原文及证据已保存" : `采集失败：${source.error}`);
      if (location.hash.endsWith("/sources")) await route(); else location.hash = `#/projects/${project.id}/sources`;
    }
    if (form.id === "run-form") {
      await api(`/projects/${project.id}/runs`, "POST", { confirmedPlan: true, webSearch: data.get("webSearch") === "on", sectionId: form.dataset.section || null, clientRequestId: crypto.randomUUID() });
      dialog.close();
      if (location.hash.endsWith("/runs")) await route(); else location.hash = `#/projects/${project.id}/runs`;
    }
  } catch (error) { fail(error); } finally { submit.disabled = false; }
});
let projectSearchTimer;
document.addEventListener("input", event => {
  const el = event.target;
  if (el.matches("[data-paragraph]")) {
    dirty = true; backupEditor(); clearTimeout(autosave);
    const status = document.querySelector(".editor-status"); if (status) status.textContent = "未保存";
    autosave = setTimeout(() => saveEditor().catch(fail), 800);
  }
  if (el.id === "project-search") {
    clearTimeout(projectSearchTimer);
    projectSearchTimer = setTimeout(async () => {
      const serial = routeSerial;
      try {
        const result = await api(`/projects?q=${encodeURIComponent(el.value)}&archived=${document.querySelector("#archive-filter").value}`);
        if (serial === routeSerial) projectRows(result.items);
      } catch (error) { fail(error); }
    }, 200);
  }
  if (el.id === "source-search") sourceRows();
});
document.addEventListener("change", async event => {
  if (event.target.name === "sourceMode") {
    dialog.querySelector("#text-fields").hidden = event.target.value !== "text";
    dialog.querySelector("#url-fields").hidden = event.target.value !== "url";
  }
  if (event.target.id === "source-filter") sourceRows();
  if (event.target.id === "archive-filter") {
    try { projectRows((await api(`/projects?archived=${event.target.value}&q=${encodeURIComponent(document.querySelector("#project-search").value)}`)).items); } catch (error) { fail(error); }
  }
});
window.addEventListener("beforeunload", event => { if (dirty || saving) { backupEditor(); event.preventDefault(); event.returnValue = ""; } });
window.addEventListener("afterprint", () => document.querySelector("#print-output")?.remove());
window.addEventListener("hashchange", route);
route();
