# 数据模型与 HTTP 契约

本文是目标契约，现有 `/api/generate-report` 等接口尚未迁移。ID 使用 UUID 字符串；时间使用 UTC ISO 8601，界面按本地时区显示。

开发更新：新版接口已由 `server/http.mjs` 实现，与本目标契约的简化差异见 [实施记录](IMPLEMENTATION.md)。旧 Demo 接口仍保留在旧入口；新版未使用它们。

## 1. 数据关系

```text
Project → Sources → Evidence
Project → ReportVersions → Sections → Claims → Evidence IDs
Project → Runs → Steps / Events / ModelCalls
Project → EditableDraft
```

引用通过不可变 evidence ID 绑定，显示的 `[1]` 只是在某个报告版本中的序号。不能用数组下标作为持久 ID。

## 2. 最小数据表

| 表 | 主要字段 | 约束 |
| --- | --- | --- |
| projects | id, title, material, question, scope_json, profile_json, enabled_sections_json, mode, revision, created_at, updated_at, archived_at | mode=real/demo；归档代替首版删除 |
| sources | id, project_id, url, title, publisher, published_at, fetched_at, status, content_hash, file_path, error_json | 版本化原文；已引用内容不原地覆写 |
| evidence | id, source_id, quote, locator_json, facts_json, created_at | 必须关联可定位片段；摘要不得冒充正文 |
| report_versions | id, project_id, parent_id, origin, content_json, created_at | origin=model/manual/demo；版本不可变 |
| report_drafts | project_id, base_version_id, revision, content_json, updated_at | 每项目一个工作草稿，乐观并发 |
| runs | id, project_id, status, input_json, fingerprint, budget_json, created_at, finished_at | input_json 保存启动时快照 |
| run_steps | id, run_id, step_key, status, attempt, input_hash, output_json, error_json | 步骤完成与输出同事务 |
| run_events | id, run_id, seq, type, payload_json, created_at | UNIQUE(run_id,seq)；可重放 |
| model_calls | id, run_id, step_id, model, provider_request_id, usage_json, duration_ms, status | 不记录密钥；失败/未知也留记录 |

启用外键。原文使用内容哈希识别重复，但不同来源链接仍保留来源元信息。资料被报告引用后只允许隐藏，不允许破坏历史引用。

`scope_json`：region、timeRange、lens。`budget_json`：maxCalls、maxDurationMs、maxSources。运行快照同时保存模型、提示词版本、选中来源及章节。

## 3. 核心对象示例

以下全部是自编数据示例，不是真实研究：

```json
{
  "id": "evidence-demo-1",
  "sourceId": "source-demo-1",
  "quote": "样品验证仍需完成长循环测试。",
  "locator": {
    "kind": "text",
    "heading": "验证进度",
    "start": 0,
    "end": 16,
    "contentHash": "example-hash"
  },
  "facts": []
}
```

`start`、`end` 的单位统一为 JS 字符串 UTF-16 code units，使用左闭右开；实际实现必须验证 `text.slice(start,end) === quote`。上例定位长度仅作形状示意，生产数据由程序计算，禁止模型生成偏移量。

```json
{
  "sectionId": "technology",
  "heading": "技术路线",
  "paragraphs": [
    {
      "id": "paragraph-demo-1",
      "text": "该路线仍需要进一步验证。",
      "claims": [
        {
          "id": "claim-demo-1",
          "text": "长循环测试尚未完成",
          "kind": "fact",
          "evidenceIds": ["evidence-demo-1"],
          "review": "unreviewed"
        }
      ]
    }
  ]
}
```

claim.kind：fact / analysis / hypothesis。review：unreviewed / supported / partial / unsupported。

用户修改含事实结论的段落后，将相关审核状态重置为 unreviewed；保留旧版本的审核记录。纯排版修改可以保留状态，但首版不做复杂语义差异判断。

数值事实的 `facts` 项包含：metric、value、unit、period、region、population、quote。无原文明确值时不补数字；来源未给日期时保留 null。

## 4. 响应与错误

成功：

```json
{"data":{"id":"project-id","revision":2}}
```

失败：

```json
{
  "error": {
    "code": "MODEL_NOT_CONFIGURED",
    "message": "请先配置模型连接，或打开演示项目。",
    "retryable": false,
    "requestId": "request-id"
  }
}
```

HTTP：400 输入不合法；404 对象不存在；409 revision 冲突或有活动运行；422 正文不可提取；429 调用受限；502 上游失败；504 超时。不要用 HTTP 200 包装一次完全失败的真实研究。

错误码至少包含：VALIDATION_ERROR、REVISION_CONFLICT、RUN_ACTIVE、MODEL_NOT_CONFIGURED、MODEL_TIMEOUT、MODEL_REFUSED、MODEL_OUTPUT_INVALID、SOURCE_BLOCKED、SOURCE_FETCH_FAILED、SOURCE_UNSUPPORTED、BUDGET_EXCEEDED、INTERNAL_ERROR。

## 5. 接口列表

所有项目作用域内的 ID 都要验证归属，不接受其他项目的证据混入。

| 方法与路径 | 输入/用途 | 成功 |
| --- | --- | --- |
| GET /api/health | 服务与 schema 版本 | 200 |
| GET /api/settings/status | configured、model、dataDirectory，不返回 key | 200 |
| POST /api/settings/check | 显式连接检查；界面说明可能产生调用 | 200 |
| GET /api/projects | q、archived、cursor、limit≤50 | 200，items/nextCursor |
| POST /api/projects | title/material/question/scope/profile/enabledSections/mode | 201，Project |
| GET /api/projects/:id | 项目详情 | 200 |
| PATCH /api/projects/:id | revision 与修改字段 | 200，revision+1 |
| GET /api/projects/:id/draft | 当前编辑草稿 | 200 |
| PUT /api/projects/:id/draft | revision、baseVersionId、content | 200，新 revision |
| POST /api/projects/:id/versions | draftRevision；把草稿存为版本 | 201 |
| GET /api/projects/:id/versions | 历史版本元信息 | 200 |
| GET /api/projects/:id/versions/:versionId | 只读完整版本 | 200 |
| POST /api/projects/:id/sources | url 或用户粘贴的 text/title；首版暂不上传 PDF | 201，待处理 Source |
| GET /api/projects/:id/sources | status/q | 200 |
| POST /api/projects/:id/sources/:sourceId/retry | 重试正文抓取 | 202 |
| GET /api/projects/:id/sources/:sourceId | 元信息与纯文本，不返回磁盘路径 | 200 |
| GET /api/projects/:id/evidence/:evidenceId | quote/locator/来源，按 ID 定位 | 200 |
| POST /api/projects/:id/plan | 保存用户确认前的研究计划，不自动开始计费生成 | 200 |
| POST /api/projects/:id/runs | scope=full/section、sectionId?、confirmedPlan、clientRequestId | 202，runId |
| GET /api/runs/:runId | 状态、步骤、用量 | 200 |
| GET /api/runs/:runId/events | SSE；Last-Event-ID 或 after | 200，text/event-stream |
| POST /api/runs/:runId/cancel | 请求取消；重复请求幂等 | 202 |
| POST /api/runs/:runId/resume | interrupted/failed/partial/cancelled 时恢复 | 202 |
| GET /api/projects/:id/export?format=md&versionId=... | 指定已保存版本 | 200，附件 |

自动保存失败不得导出“看似最新”的旧版本。导出前先保存并创建版本，或让用户明确选择已有版本。

计划首版通过规则生成可编辑检索词和章节列表；若后续改为模型规划，需单独记用量并更新 UI。

## 6. 执行事件

```text
id: 17
event: step.updated
data: {"runId":"run-id","stepKey":"collect","status":"running","completed":3,"total":8}
```

事件：run.started、step.updated、source.ready、section.ready、usage.updated、run.finished、run.failed、run.cancelled。事件只带 UI 所需摘要，完整数据由详情接口读取。

事件先落库后推送；浏览器按 seq 去重，重连补拉。事件只作为通知，不能决定数据库状态。断流显示“连接已断开，正在重连”，不把运行标记为失败。

## 7. 并发与幂等

首版整个进程最多一个活动 run，其余请求返回 RUN_ACTIVE 和正在运行的项目。使用事务确保检查与创建不可分割。

`clientRequestId` 对同项目的启动请求唯一，重试相同请求返回同一 run。不能承诺外部模型“恰好调用一次”：网络超时可能已计费但未取得结果，记录状态为 unknown，恢复前告知可能重新调用。

草稿更新通过 revision 实现乐观锁。两个标签页冲突时保留本地草稿，提供加载服务端版本或另存版本，不静默覆盖。

## 8. 首版输入上限

拟定且需要实际测试：单个普通 JSON 请求 1 MiB；粘贴文本 200,000 字符；网页响应 5 MiB；每次运行最多 12 个来源；只抓取一层页面，不递归爬站。超限返回明确错误，不无提示截断。
